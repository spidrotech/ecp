/**
 *  @file   checkpoint.c
 *  @author Leonardo A. Bautista Gomez (leobago@gmail.com)
 *  @date   July, 2013
 *  @brief  Checkpointing functions for the FTI library.
 */


#include "fti.h"


/*-------------------------------------------------------------------------*/
/**
    @brief      Decides wich action start depending on the ckpt. level.
    @return     integer         FTI_SCES if successful.

    This function launchs the required action dependeing on the ckpt. level.
    It does thast for each group (application process in the node).

 **/
/*-------------------------------------------------------------------------*/
int FTI_CkptNotified() {
    char str[FTI_BUFS];
    int res, i, rank;
    unsigned long maxFs, fs;
    double timer = MPI_Wtime(); // For timing checkpoint post-processing
    if (FTI_Topo.amIaHead) { // If I am the Head
        FTI_GetMeta(&fs, &maxFs, 0, 1); // To get checkpoint ID
        sscanf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", &FTI_Exec.ckptID, &res);
        for(i = 0; i < FTI_Topo.nbApprocs; i++) { // I post-process every ckpt. in the node
            switch(FTI_Exec.ckptLvel) { // Action required depending on the ckpt. level
                case 4 : if (!FTI_Ckpt.l4Inline) res = FTI_Flush    (i); break;
                case 3 : if (!FTI_Ckpt.l3Inline) res = FTI_RSencode (i); break;
                case 2 : if (!FTI_Ckpt.l2Inline) res = FTI_Partner  (i); break;
                case 1 : res = FTI_SCES; break;
            }
        }
        FTI_Print("Barrier before cleaning previous checkpoint.", FTI_DBUG); MPI_Barrier(FTI_COMM_WORLD);
        for(i = 0; i < FTI_Topo.nbApprocs; i++) FTI_Clean(FTI_Exec.lastCkptLvel, i, FTI_Topo.body[i]);
        FTI_Print("Barrier after cleaning previous checkpoint.", FTI_DBUG); MPI_Barrier(FTI_COMM_WORLD);
    } else { // If I am not Head I only post-process my ckpt.
        switch(FTI_Exec.ckptLvel) { // Action required depending on the ckpt. level
            case 4 : if (FTI_Ckpt.l4Inline) res = FTI_SCES; break;
            case 3 : if (FTI_Ckpt.l3Inline) res = FTI_RSencode(FTI_Topo.groupID); break;
            case 2 : if (FTI_Ckpt.l2Inline) res = FTI_Partner(FTI_Topo.groupID); break;
            case 1 : res = FTI_SCES; break;
        }
        FTI_Print("Barrier before cleaning previous checkpoint.", FTI_DBUG); MPI_Barrier(FTI_COMM_WORLD);
        FTI_Clean(FTI_Exec.lastCkptLvel, FTI_Topo.groupID, FTI_Topo.myRank);
        FTI_Print("Barrier after cleaning previous checkpoint.", FTI_DBUG); MPI_Barrier(FTI_COMM_WORLD);
    }
    rename(FTI_Ckpt.newL1Dir, FTI_Ckpt.oldL1Dir); // Archive checkpoint
    if (FTI_Exec.ckptLvel == 4) rename(FTI_Ckpt.newL4Dir, FTI_Ckpt.oldL4Dir);
    if (FTI_Exec.ckptLvel == 4) FTI_Ckpt.l4LastCkpt = FTI_Exec.ckptID; // Save ID of the last L4 ckpt.
    rename(FTI_Conf.newMtDir, FTI_Conf.oldMtDir);
    FTI_Exec.lastCkptLvel = FTI_Exec.ckptLvel;
    FTI_Exec.ckptID++;
    sprintf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", FTI_Exec.ckptID, FTI_Topo.myRank);
    sprintf(str, "Ckpt. post-processing at L%d took %f seconds.", FTI_Exec.ckptLvel, MPI_Wtime()-timer);
    if (res == FTI_SCES) FTI_Print(str, FTI_DBUG);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It copies ckpt. files in to the partner node.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function copies the checkpoint files into the pertner node. It
    follows a ring, where the ring size is the group size given in the FTI
    configuration file.

 **/
/*-------------------------------------------------------------------------*/
int FTI_Partner(int group) {
    char        *blBuf1, *blBuf2, lfn[FTI_BUFS], pfn[FTI_BUFS], str[FTI_BUFS];
    unsigned long maxFs, fs, ps, pos = 0; // FTI_BUFS > 32
    int         dest, src;
    MPI_Request reqSend, reqRecv;
    FILE        *lfd, *pfd;
    MPI_Status  status;
    blBuf1 = talloc(char, FTI_Conf.blockSize);
    blBuf2 = talloc(char, FTI_Conf.blockSize);
    if (FTI_GetMeta(&fs, &maxFs, group, 1) == FTI_SCES) FTI_Print("Metadata obtained.", FTI_DBUG); // Get metadata
    ps = (maxFs/FTI_Conf.blockSize)*FTI_Conf.blockSize;
    if (ps < maxFs) ps = ps + FTI_Conf.blockSize;
    sprintf(str, "Max. file size %ld and padding size %ld.", maxFs, ps); FTI_Print(str, FTI_DBUG);
    sscanf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", &FTI_Exec.ckptID, &src);
    sprintf(lfn,"%s/%s",FTI_Ckpt.newL1Dir, FTI_Exec.ckptFile);
    sprintf(pfn,"%s/Ckpt%d-Pcof%d.fti", FTI_Ckpt.newL1Dir, FTI_Exec.ckptID, src);
    sprintf(str, "L2 trying to access local ckpt. file (%s).", lfn); FTI_Print(str, FTI_DBUG);
    dest = FTI_Topo.right; // Defining source and destination partners
    src = FTI_Topo.left;
    if (access(lfn, R_OK) != 0) FTI_Print("L2 cannot access the checkpoint file.", FTI_EROR);
    if (truncate(lfn,ps) == -1) FTI_Print("L2 cannot truncate the checkpoint file.", FTI_EROR);
    lfd = fopen(lfn, "rb"); if (lfd == NULL) FTI_Print("L2 cannot open the checkpoint file.", FTI_EROR);
    pfd = fopen(pfn, "wb"); if (pfd == NULL) FTI_Print("L2 cannot open the partner ckpt. file.", FTI_EROR);
    while(pos < ps) { // Checkpoint files partner copy
        fread(blBuf1, sizeof(char), FTI_Conf.blockSize, lfd);
        MPI_Isend(blBuf1, FTI_Conf.blockSize, MPI_CHAR, dest, FTI_Conf.tag, FTI_Exec.groupComm, &reqSend);
        MPI_Irecv(blBuf2, FTI_Conf.blockSize, MPI_CHAR, src, FTI_Conf.tag, FTI_Exec.groupComm, &reqRecv);
        MPI_Wait(&reqSend, &status);
        MPI_Wait(&reqRecv, &status);
        fwrite(blBuf2, sizeof(char), FTI_Conf.blockSize, pfd);
        pos = pos + FTI_Conf.blockSize;
    }
    fclose(lfd); fclose(pfd); // Close files
    if (truncate(lfn,fs) == -1) FTI_Print("L2 cannot re-truncate the checkpoint file.", FTI_EROR);
    if (truncate(pfn,fs) == -1) FTI_Print("L2 cannot re-truncate the partner ckpt. file.", FTI_EROR);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It performs RS encoding with the ckpt. files in to the group.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function performs the Reed-Solomon encoding for a given group. The
    checkpoint files are padded to the maximum size of the largest checkpoint
    file in the group +- the extra space to be a multiple of block size.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RSencode(int group) {
    char *myData, *data, *coding, lfn[FTI_BUFS], efn[FTI_BUFS], str[FTI_BUFS];
    int *matrix, cnt, i, init, src, offset, dest, matVal, bs = FTI_Conf.blockSize;
    unsigned long maxFs, fs, ps, pos = 0; // FTI_BUFS > 32
    MPI_Request reqSend, reqRecv;
    MPI_Status status;
    FILE *lfd, *efd;
    if (FTI_GetMeta(&fs, &maxFs, group, 1) == FTI_SCES) FTI_Print("Metadata obtained.", FTI_DBUG); // Get metadata
    ps = ((maxFs/bs))*bs;
    if (ps < maxFs) ps = ps + bs; // Calculating padding size
    myData = talloc(char, bs);
    data = talloc(char, 2*bs);
    coding = talloc(char, bs);
    matrix =  talloc(int, FTI_Topo.groupSize*FTI_Topo.groupSize);
    if (FTI_CreateMatrix(matrix) == FTI_SCES) FTI_Print("Matrix created.", FTI_DBUG);
    sprintf(lfn,"%s/%s",FTI_Ckpt.newL1Dir, FTI_Exec.ckptFile);
    sprintf(efn,"%s/%s.enc",FTI_Ckpt.newL1Dir, FTI_Exec.ckptFile);
    sprintf(str, "L3 trying to access local ckpt. file (%s).", lfn); FTI_Print(str, FTI_DBUG);
    if (access(lfn, R_OK) != 0) FTI_Print("L3 cannot access the checkpoint file.", FTI_EROR);
    if (truncate(lfn,ps) == -1) FTI_Print("L3 cannot truncate the checkpoint file.", FTI_EROR);
    lfd = fopen(lfn, "rb"); if (lfd == NULL) FTI_Print("L3 cannot open checkpoint file.", FTI_EROR);
    efd = fopen(efn, "wb"); if (efd == NULL) FTI_Print("L3 cannot open encoded ckpt. file.", FTI_EROR);
    while(pos < ps) { // For each block
        fread(myData, sizeof(char), bs, lfd); // Reading checkpoint files
        dest = FTI_Topo.groupRank; i = FTI_Topo.groupRank; offset = 0; init = 0; cnt = 0; // For the logic
        while(cnt < FTI_Topo.groupSize) { // For each encoding
            if (cnt == 0) memcpy(&(data[offset*bs]), myData, sizeof(char)*bs);
            else { MPI_Wait(&reqSend, &status); MPI_Wait(&reqRecv, &status); }
            if (cnt != FTI_Topo.groupSize-1) { // At every loop *but* the last one we send the data
                dest = (dest+FTI_Topo.groupSize-1)%FTI_Topo.groupSize;
                src = (i+1)%FTI_Topo.groupSize;
                MPI_Isend(myData, bs, MPI_CHAR, dest, FTI_Conf.tag, FTI_Exec.groupComm, &reqSend);
                MPI_Irecv(&(data[(1-offset)*bs]), bs, MPI_CHAR, src, FTI_Conf.tag, FTI_Exec.groupComm, &reqRecv);
            }
            matVal = matrix[FTI_Topo.groupRank*FTI_Topo.groupSize+i];
            if (matVal == 1) { // First copy or xor any data that does not need to be multiplied by a factor
                if (init == 0) { memcpy(coding, &(data[offset*bs]), bs); init = 1; }
                else galois_region_xor(&(data[offset*bs]), coding, coding, bs);
            }
            if (matVal != 0 && matVal != 1) // Then the data that needs to be multiplied by a factor
                { galois_w16_region_multiply(&(data[offset*bs]), matVal, bs, coding, init); init = 1; }
            i = (i+1)%FTI_Topo.groupSize; offset = 1 - offset; cnt++; // For the logic
        }
        fwrite(coding, sizeof(char), bs, efd); // Writting encoded checkpoints
        pos = pos + bs; // Next block
    }
    fclose(lfd); fclose(efd); // Closing and resizing files
    if (truncate(lfn,fs) == -1) FTI_Print("L3 cannot re-truncate the checkpoint file.", FTI_EROR);
    if (truncate(efn,fs) == -1) FTI_Print("L3 cannot re-truncate the encoded ckpt. file.", FTI_EROR);
    free(data); free(matrix); free(coding); free(myData); // Freeing memory
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It flushes the local ckpt. files in to the PFS.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function flushes the local checkpoint files in to the PFS. The files
    are padded to match the block size and then truncated.

 **/
/*-------------------------------------------------------------------------*/
int FTI_Flush(int group) {
    char        lfn[FTI_BUFS], gfn[FTI_BUFS], str[FTI_BUFS], *blBuf1 = talloc(char, FTI_Conf.blockSize);
    unsigned long maxFs, fs, ps, pos = 0; // FTI_BUFS > 32
    FILE        *lfd, *gfd;
    if (FTI_GetMeta(&fs, &maxFs, group, 1) == FTI_SCES) FTI_Print("Metadata obtained.", FTI_DBUG); // Get metadata
    if (access(FTI_Ckpt.newL4Dir, F_OK) != 0) mkdir(FTI_Ckpt.newL4Dir, 0777);
    ps = (maxFs/FTI_Conf.blockSize)*FTI_Conf.blockSize;
    if (ps < maxFs) ps = ps + FTI_Conf.blockSize;
    sprintf(lfn,"%s/%s", FTI_Ckpt.newL1Dir, FTI_Exec.ckptFile);
    sprintf(gfn,"%s/%s", FTI_Ckpt.newL4Dir, FTI_Exec.ckptFile); // Open and resize files
    sprintf(str, "L4 trying to access local ckpt. file (%s).", lfn); FTI_Print(str, FTI_DBUG);
    if (access(lfn, R_OK) != 0) FTI_Print("L4 cannot access the checkpoint file.", FTI_EROR);
    if (truncate(lfn,ps) == -1) FTI_Print("L4 cannot truncate the checkpoint file.", FTI_EROR);
    lfd = fopen(lfn, "rb"); if (lfd == NULL) FTI_Print("L4 cannot open the checkpoint file.", FTI_EROR);
    gfd = fopen(gfn, "wb"); if (gfd == NULL) FTI_Print("L4 cannot open ckpt. file in the PFS.", FTI_EROR);
    while(pos < ps) { // Checkpoint files exchange
        fread(blBuf1, sizeof(char), FTI_Conf.blockSize, lfd);
        fwrite(blBuf1, sizeof(char), FTI_Conf.blockSize, gfd);
        pos = pos + FTI_Conf.blockSize;
    }
    if (truncate(lfn,fs) == -1) FTI_Print("L4 cannot re-truncate the checkpoint file.", FTI_EROR);
    if (truncate(gfn,fs) == -1) FTI_Print("L4 cannot re-truncate the ckpt. file on PFS.", FTI_EROR);
    fclose(lfd); fclose(gfd); // Close files
    return FTI_SCES;
}


