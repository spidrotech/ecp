/**
 *  @file   tools.c
 *  @author Leonardo A. Bautista Gomez (leobago@gmail.com)
 *  @date   July, 2013
 *  @brief  Utility functions for the FTI library.
 */


#include "fti.h"


/*-------------------------------------------------------------------------*/
/**
    @brief      Prints FTI messages.
    @param      s               Message to print.
    @param      priority        Priority of the message to be printed.
    @return     void

    This function prints messages depending on their priority and the
    verbosity level set by the user. DEBUG messages are printed by all
    processes with their rank. INFO messages are printed by one process.
    ERROR messages are printed and then the application is killed.

 **/
/*-------------------------------------------------------------------------*/
void FTI_Print(char *s, int priority) {
    if (priority >= FTI_Conf.verbosity) {
        if (s != NULL) {
            switch(priority) {
                case FTI_EROR:
                    fprintf(stderr, "[FTI Error - %06d] : %s : %s \n", FTI_Topo.myRank, s, strerror(errno));
                    FTI_Clean(5, FTI_Topo.groupID, FTI_Topo.myRank);
                    MPI_Abort(MPI_COMM_WORLD, -1);
                    MPI_Finalize();
                    exit(1);
                case FTI_INFO:
                    if (FTI_Topo.splitRank == 0)
                        fprintf(stdout, "[FTI Infos - %06d] : %s \n", FTI_Topo.myRank, s);
                    break;
                case FTI_DBUG:
                    fprintf(stdout, "[FTI Debug - %06d] : %s \n", FTI_Topo.myRank, s);
                    break;
                default:
                    break;
            }
        }
    }
    fflush(stdout);
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Creates a distribution matrix for the RS encoding.
    @param      matrix          Matrix to be filled.
    @return     integer         FTI_SCES if successfull.

    This function creates a distribution matrix for the RS encoding and
    fill the values of the one passed in parameter. It uses the FTI
    configuration and the jerasure library.

 **/
/*-------------------------------------------------------------------------*/
int FTI_CreateMatrix(int *matrix) {
    int i,j;
    for (i = 0; i < FTI_Topo.groupSize; i++) {
        for (j = 0; j < FTI_Topo.groupSize; j++) {
            matrix[i*FTI_Topo.groupSize+j] = galois_single_divide(1, i ^ (FTI_Topo.groupSize + j), FTI_Ckpt.l3WordSize);
        }
    }
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Set the exec. ID and failure parameters in the conf. file.
    @param      restart         Value to set in the conf. file (0 or 1).
    @return     integer         FTI_SCES if successfull.

    This function sets the execution ID and failure parameters in the
    configuration file. This is to avoid forcing the user to change these
    values manually in case of recovery needed. In this way, relaunching the
    execution in the same way as the initial time will make FTI detect that
    it is a restart. It also allows to set the failure parameter back to 0
    at the end of a successful execution.

 **/
/*-------------------------------------------------------------------------*/
int FTI_UpdateConf(int restart) {
    char str[FTI_BUFS];
    dictionary *ini;
    ini = iniparser_load(FTI_Conf.cfgFile); // Load dictionary
    sprintf(str, "Updating configuration file (%s)...", FTI_Conf.cfgFile);
    FTI_Print(str, FTI_DBUG);
    if (ini != NULL) FTI_Print("Iniparser parsed the configuration file.", FTI_DBUG);
    else return FTI_NSCS;
    sprintf(str, "%d", restart);
    iniparser_set(ini, "Restart:failure", str); // Set failure to 'restart'
    iniparser_set(ini, "Restart:exec_id", FTI_Exec.id); // Set the execution ID
    FILE *fd = fopen(FTI_Conf.cfgFile, "w");
    if (fd != NULL) FTI_Print("Configuration file opened.", FTI_DBUG);
    else return FTI_NSCS;
    iniparser_dump_ini(ini, fd); // Write new configuration
    if (fflush(fd) == 0) FTI_Print("Configuration file flushed.", FTI_DBUG);
    else return FTI_NSCS;
    if (fclose(fd) == 0) FTI_Print("Configuration file closed.", FTI_DBUG);
    else return FTI_NSCS;
    iniparser_freedict(ini); // Free dictionary
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It creates and broadcast a global execution ID.
    @return     integer         FTI_SCES if successfull.

    This function creates and broadcast an execution ID, so that all ranks
    have the same execution ID.

 **/
/*-------------------------------------------------------------------------*/
int FTI_CreateExecID() {
    time_t tim = time(NULL);
    struct tm *now = localtime(&tim);
    snprintf(FTI_Exec.id, FTI_BUFS, "%d-%02d-%02d_%02d-%02d-%02d",
            now->tm_year+1900, now->tm_mon+1, now->tm_mday, now->tm_hour, now->tm_min, now->tm_sec);
    MPI_Bcast(FTI_Exec.id, FTI_BUFS, MPI_CHAR, 0, FTI_Exec.globalComm);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It reads the configuration given in the configuration file.
    @return     integer         FTI_SCES if successfull.

    This function reads the configuration given in the FTI configuration
    file and sets other required parameters.

 **/
/*-------------------------------------------------------------------------*/
int FTI_ReadConf() {
    // Check access to FTI configuration file and load dictionary
    dictionary *ini;
    char *par, str[FTI_BUFS];
    sprintf(str, "Reading FTI configuration file (%s)...", FTI_Conf.cfgFile);
    FTI_Print(str, FTI_DBUG);
    if (access(FTI_Conf.cfgFile, F_OK) == 0) FTI_Print("FTI configuration file accessible.", FTI_DBUG);
    else FTI_Print("FTI configuration file NOT accessible.", FTI_EROR);
    ini = iniparser_load(FTI_Conf.cfgFile);
    if (ini != NULL) FTI_Print("Iniparser parsed the FTI configuration file.", FTI_DBUG);
    else FTI_Print("Iniparser could NOT parse the FTI configuration file.", FTI_EROR);

    // Setting/reading checkpoint configuration metadata
    par = iniparser_getstring(ini, "Basic:ckpt_dir", NULL);
    snprintf(FTI_Ckpt.l1Dir, FTI_BUFS, "%s", par);
    par = iniparser_getstring(ini, "Basic:glbl_dir", NULL);
    snprintf(FTI_Ckpt.l4Dir, FTI_BUFS, "%s", par);
    FTI_Ckpt.l1CkptIntv = (int) iniparser_getint(ini, "Basic:ckpt_int", -1);
    FTI_Ckpt.l2CkptIntv = (int) iniparser_getint(ini, "Basic:ckpt_l2", -1);
    FTI_Ckpt.l3CkptIntv = (int) iniparser_getint(ini, "Basic:ckpt_l3", -1);
    FTI_Ckpt.l4CkptIntv = (int) iniparser_getint(ini, "Basic:ckpt_l4", -1);
    FTI_Ckpt.isInline[2] = (int) iniparser_getint(ini, "Basic:inline_l2", 0);
    FTI_Ckpt.isInline[3] = (int) iniparser_getint(ini, "Basic:inline_l3", 0);
    FTI_Ckpt.isInline[4] = (int) iniparser_getint(ini, "Basic:inline_l4", 0);
    FTI_Ckpt.l3WordSize = FTI_WORD;

    // Reading/setting configuration metadata
    par = iniparser_getstring(ini, "Basic:meta_dir", NULL);
    snprintf(FTI_Conf.metaDir, FTI_BUFS, "%s", par);
    FTI_Conf.verbosity = (int) iniparser_getint(ini, "Basic:verbosity", -1);
    FTI_Conf.saveLastCkpt = (int) iniparser_getint(ini, "Basic:keep_last_ckpt", 0);
    FTI_Conf.blockSize = (int) iniparser_getint(ini, "Advanced:block_size", -1) * 1024;
    FTI_Conf.tag = (int) iniparser_getint(ini, "Advanced:mpi_tag", -1);
    FTI_Conf.test = (int) iniparser_getint(ini, "Advanced:local_test", -1);

    // Reading/setting execution metadata
    FTI_Exec.nbVar = 0;
    FTI_Exec.ckpt = 0;
    FTI_Exec.ckptCnt = 0;
    FTI_Exec.ckptID = 1;
    FTI_Exec.ckptLvel = 0;
    FTI_Exec.wasLastOffline = 0;
    FTI_Exec.ckptNext = FTI_Ckpt.l1CkptIntv;
    FTI_Exec.reco = (int) iniparser_getint(ini, "restart:failure", 0);
    if (FTI_Exec.reco == 0) {
        FTI_CreateExecID();
        sprintf(str, "The execution ID is: %s", FTI_Exec.id);
        FTI_Print(str, FTI_INFO);
        snprintf(FTI_Exec.ckptFile, FTI_BUFS, "Ckpt%d-Rank%d.fti", FTI_Exec.ckptID, FTI_Topo.myRank);
    } else {
        par = iniparser_getstring(ini, "restart:exec_id", NULL);
        snprintf(FTI_Exec.id, FTI_BUFS, "%s", par);
        sprintf(str, "This is a restart. The execution ID is: %s", FTI_Exec.id);
        FTI_Print(str, FTI_INFO);
    }

    // Reading/setting topology metadata
    FTI_Topo.nbHeads = (int) iniparser_getint(ini, "Basic:head", 0);
    FTI_Topo.groupSize = (int) iniparser_getint(ini, "Basic:group_size", -1);
    FTI_Topo.nodeSize = (int) iniparser_getint(ini, "Basic:node_size", -1);
    FTI_Topo.nbApprocs = FTI_Topo.nodeSize - FTI_Topo.nbHeads;
    FTI_Topo.nbNodes = FTI_Topo.nbProc / FTI_Topo.nodeSize;

    // Synchronize after config reading and free dictionary
    MPI_Barrier(FTI_Exec.globalComm);
    iniparser_freedict(ini);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It tests that the configuration given is correct.
    @return     integer         FTI_SCES if successfull.

    This function tests the FTI configuration to make sure that all
    parameter's values are correct.

 **/
/*-------------------------------------------------------------------------*/
int FTI_TestConfig() {
    // Checking topology
    char str[FTI_BUFS];

    if (FTI_Topo.nbHeads != 0 && FTI_Topo.nbHeads != 1)
        FTI_Print("The number of heads needs to be set to 0 or 1.", FTI_EROR);
    if (FTI_Topo.nbProc % FTI_Topo.nodeSize != 0)
        FTI_Print("Number of ranks is not a multiple of the node size.", FTI_EROR);
    if (FTI_Topo.nbNodes % FTI_Topo.groupSize != 0)
        FTI_Print("The group size is not multiple of the number of nodes.", FTI_EROR);
    if (FTI_Topo.groupSize <= 2)
        FTI_Print("The group size must be bigger than 2", FTI_EROR);
    if (FTI_Topo.groupSize >= 32)
        FTI_Print("The group size must be lower than 32", FTI_EROR);

    // Checking general configuration
    if (FTI_Conf.verbosity > 3 || FTI_Conf.verbosity < 1)
        FTI_Print("Verbosity needs to be set to 1, 2 or 3.", FTI_EROR);
    if (FTI_Conf.blockSize > (2048*1024) || FTI_Conf.blockSize < (1*1024))
        FTI_Print("Block size needs to be set between 1 and 2048.", FTI_EROR);
    if (FTI_Conf.test != 0 && FTI_Conf.test != 1)
        FTI_Print("Local test size needs to be set to 0 or 1.", FTI_EROR);
    if (FTI_Conf.saveLastCkpt != 0 && FTI_Conf.saveLastCkpt != 1)
        FTI_Print("Keep last ckpt. needs to be set to 0 or 1.", FTI_EROR);


    // Checking checkpoint configuration
    if (FTI_Ckpt.l1CkptIntv == 0) FTI_Ckpt.l1CkptIntv = -1;
    if (FTI_Ckpt.l2CkptIntv == 0) FTI_Ckpt.l2CkptIntv = -1;
    if (FTI_Ckpt.l3CkptIntv == 0) FTI_Ckpt.l3CkptIntv = -1;
    if (FTI_Ckpt.l4CkptIntv == 0) FTI_Ckpt.l4CkptIntv = -1;
    if (FTI_Ckpt.isInline[2] != 0 && FTI_Ckpt.isInline[2] != 1) FTI_Ckpt.isInline[2] = 0;
    if (FTI_Ckpt.isInline[3] != 0 && FTI_Ckpt.isInline[3] != 1) FTI_Ckpt.isInline[3] = 0;
    if (FTI_Ckpt.isInline[4] != 0 && FTI_Ckpt.isInline[4] != 1) FTI_Ckpt.isInline[4] = 0;
    if (FTI_Ckpt.isInline[2] == 0 && FTI_Topo.nbHeads != 1)
        FTI_Print("If inline_l2 is set to 0 then head should be set to 1.", FTI_EROR);
    if (FTI_Ckpt.isInline[3] == 0 && FTI_Topo.nbHeads != 1)
        FTI_Print("If inline_l3 is set to 0 then head should be set to 1.", FTI_EROR);
    if (FTI_Ckpt.isInline[4] == 0 && FTI_Topo.nbHeads != 1)
        FTI_Print("If inline_l4 is set to 0 then head should be set to 1.", FTI_EROR);

    // Checking metadata directory
    sprintf(str,"Checking the metadata directory (%s)...", FTI_Conf.metaDir);
    FTI_Print(str, FTI_DBUG);
    if (access(FTI_Conf.metaDir, W_OK) != 0) {
        FTI_Print("The metadata directory does not exist or has no write access.", FTI_DBUG);
        if (mkdir(FTI_Conf.metaDir, 0777) != 0)
            FTI_Print("The metadata directory could NOT be created.", FTI_EROR);
    }

    // Checking local directory
    sprintf(str,"Checking the local directory (%s)...", FTI_Ckpt.l1Dir);
    FTI_Print(str, FTI_DBUG);
    if (access(FTI_Ckpt.l1Dir, W_OK) != 0) {
        FTI_Print("The local directory does not exist or has no write access.", FTI_DBUG);
        if (mkdir(FTI_Ckpt.l1Dir, 0777) != 0)
            FTI_Print("The local directory could NOT be created.", FTI_EROR);
    }

    // Checking global directory
    sprintf(str,"Checking the global directory (%s)...", FTI_Ckpt.l4Dir);
    FTI_Print(str, FTI_DBUG);
    if (access(FTI_Ckpt.l4Dir, W_OK) != 0) {
        FTI_Print("The global directory does not exist or has no write access.", FTI_DBUG);
        if (mkdir(FTI_Ckpt.l4Dir, 0777) != 0)
            FTI_Print("The global directory could NOT be created.", FTI_EROR);
    }

    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It creates the directories required for current execution.
    @return     integer         FTI_SCES if successfull.

    This function creates the temporary metadata, local and global
    directories required for the current execution.

 **/
/*-------------------------------------------------------------------------*/
int FTI_CreateDirs() {
    // Create metadata timestamp directory
    char fn[FTI_BUFS];
    snprintf(fn, FTI_BUFS, "%s/%s", FTI_Conf.metaDir, FTI_Exec.id);
    if (access(fn, F_OK) != 0) mkdir(fn, 0777);
    snprintf(FTI_Conf.metaDir, FTI_BUFS, "%s", fn);
    snprintf(FTI_Conf.newMtDir, FTI_BUFS, "%s/new", fn);
    snprintf(FTI_Conf.oldMtDir, FTI_BUFS, "%s/old", fn);
    // Create global checkpoint timestamp directory
    snprintf(fn, FTI_BUFS, "%s", FTI_Ckpt.l4Dir);
    snprintf(FTI_Ckpt.l4Dir, FTI_BUFS, "%s/%s", fn, FTI_Exec.id);
    if (access(FTI_Ckpt.l4Dir, F_OK) != 0) mkdir(FTI_Ckpt.l4Dir, 0777);
    snprintf(FTI_Ckpt.newL4Dir, FTI_BUFS, "%s/new", FTI_Ckpt.l4Dir);
    snprintf(FTI_Ckpt.oldL4Dir, FTI_BUFS, "%s/old", FTI_Ckpt.l4Dir);
    // Create local checkpoint timestamp directory
    if (FTI_Conf.test) { // If local test generate name by topology
        snprintf(fn, FTI_BUFS, "%s/node%d", FTI_Ckpt.l1Dir, FTI_Topo.myRank/FTI_Topo.nodeSize);
        if (access(fn, F_OK) != 0) mkdir(fn, 0777);
    } else {
        snprintf(fn, FTI_BUFS, "%s", FTI_Ckpt.l1Dir);
    }
    snprintf(FTI_Ckpt.l1Dir, FTI_BUFS, "%s/%s", fn, FTI_Exec.id);
    if (access(FTI_Ckpt.l1Dir, F_OK) != 0) mkdir(FTI_Ckpt.l1Dir, 0777);
    snprintf(FTI_Ckpt.newL1Dir, FTI_BUFS, "%s/new", FTI_Ckpt.l1Dir);
    snprintf(FTI_Ckpt.oldL1Dir, FTI_BUFS, "%s/old", FTI_Ckpt.l1Dir);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It gets the metadata to recover the data after a failure.
    @param      fs              Pointer to fill the checkpoint file size.
    @param      mfs             Pointer to fill the maximum file size.
    @param      group           The group in the node.
    @param      new             TRUE if it we want metadata from new ckpt.
    @return     integer         FTI_SCES if successfull.

    This function read the metadata file created during checkpointing and
    recover the checkpoint file name, file size and the size of the largest
    file in the group (for padding if ncessary during decoding).

 **/
/*-------------------------------------------------------------------------*/
int FTI_GetMeta(unsigned long *fs, unsigned long *mfs, int group, int new) {
    dictionary *ini;
    char mfn[FTI_BUFS], str[FTI_BUFS], *cfn;
    if(new) sprintf(mfn,"%s/sector%d-group%d.fti",FTI_Conf.newMtDir, FTI_Topo.sectorID, group);
    else sprintf(mfn,"%s/sector%d-group%d.fti",FTI_Conf.oldMtDir, FTI_Topo.sectorID, group);
    sprintf(str, "Getting FTI metadata file (%s)...",mfn);
    FTI_Print(str, FTI_DBUG);
    if (access(mfn, R_OK) == 0) FTI_Print("FTI metadata file accessible.", FTI_DBUG);
    else FTI_Print("FTI metadata file NOT accessible.", FTI_EROR);
    ini = iniparser_load(mfn);
    if (ini != NULL) FTI_Print("Iniparser parsed the FTI metadata file.", FTI_DBUG);
    else FTI_Print("Iniparser cannot parse the FTI metadata file.", FTI_EROR);
    sprintf(str, "%d:Ckpt_file_name", FTI_Topo.groupRank);
    cfn = iniparser_getstring(ini, str, NULL);
    snprintf(FTI_Exec.ckptFile, FTI_BUFS, "%s", cfn);
    sprintf(str, "%d:Ckpt_file_size", FTI_Topo.groupRank);
    *fs = (int) iniparser_getint(ini, str, -1);
    sprintf(str, "%d:Ckpt_file_maxs", FTI_Topo.groupRank);
    *mfs = (int) iniparser_getint(ini, str, -1);
    iniparser_freedict(ini);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It writes the metadata to recover the data after a failure.
    @return     integer         FTI_SCES if successfull.

    This function gathers information about the checkpoint files in the
    group (name and sizes), and creates the metadata file used to recover in
    case of failure.

 **/
/*-------------------------------------------------------------------------*/
int FTI_CreateMetadata() {
    char str[FTI_BUFS], buf[FTI_BUFS], *fnl = talloc(char, FTI_Topo.groupSize*FTI_BUFS);
    unsigned long fs[FTI_BUFS], mfs;
    struct stat fileStatus;
    unsigned long tmpo;
    dictionary *ini;
    int i, start;
    if (FTI_Ckpt.isInline[4] && FTI_Exec.ckptLvel == 4) sprintf(buf,"%s/%s",FTI_Ckpt.newL4Dir, FTI_Exec.ckptFile);
    else sprintf(buf,"%s/%s",FTI_Ckpt.newL1Dir, FTI_Exec.ckptFile); // Getting size of files
    if(stat(buf, &fileStatus) == 0) fs[FTI_Topo.groupRank] = (unsigned long) fileStatus.st_size;
    else FTI_Print("Error with stat on the checkpoint file.", FTI_EROR);
    sprintf(str, "Checkpoint file size : %ld bytes.", fs[FTI_Topo.groupRank]); FTI_Print(str, FTI_DBUG);
    sprintf(fnl+(FTI_Topo.groupRank*FTI_BUFS),"%s",FTI_Exec.ckptFile);
    tmpo = fs[FTI_Topo.groupRank]; // Gather all the file sizes
    MPI_Allgather(&tmpo, 1, MPI_UNSIGNED_LONG, fs, 1, MPI_UNSIGNED_LONG, FTI_Exec.groupComm);
    strncpy(str,fnl+(FTI_Topo.groupRank*FTI_BUFS),FTI_BUFS); // Gather all the file names
    MPI_Allgather(str, FTI_BUFS, MPI_CHAR, fnl, FTI_BUFS, MPI_CHAR, FTI_Exec.groupComm);
    mfs = 0; for(i = 0; i < FTI_Topo.groupSize; i++) if (fs[i] > mfs) mfs = fs[i]; // Search max. size
    sprintf(str, "Max. file size %ld.", mfs); FTI_Print(str, FTI_DBUG);
    if (FTI_Topo.groupRank == 0) { // Only one process in the group create the metadata
        snprintf(buf, FTI_BUFS, "%s/Topology.fti",FTI_Conf.metaDir);
        sprintf(str, "Temporary load of topology file (%s)...", buf);
        FTI_Print(str, FTI_DBUG);
        ini = iniparser_load(buf); // To bypass iniparser bug while empty dictionary
        if (ini != NULL) FTI_Print("Temporary topology file parsed", FTI_DBUG);
        else FTI_Print("Temporary topology file could NOT be parsed", FTI_EROR);
        //if (FTI_Topo.nbHeads == 1) start = 0; else start = 0;
        for (i = 0; i < FTI_Topo.groupSize; i++) { // Add metadata to dictionary
            strncpy(buf,fnl+(i*FTI_BUFS),FTI_BUFS);
            sprintf(str,"%d", i);
            iniparser_set(ini, str, NULL);
            sprintf(str,"%d:Ckpt_file_name", i);
            iniparser_set(ini, str, buf);
            sprintf(str,"%d:Ckpt_file_size", i);
            sprintf(buf,"%ld", fs[i]);
            iniparser_set(ini, str, buf);
            sprintf(str,"%d:Ckpt_file_maxs", i);
            sprintf(buf,"%ld", mfs);
            iniparser_set(ini, str, buf);
        }
        iniparser_unset(ini, "topology"); // Remove topology section
        if (access(FTI_Conf.newMtDir, F_OK) != 0) mkdir(FTI_Conf.newMtDir, 0777);
        sprintf(buf, "%s/sector%d-group%d.fti", FTI_Conf.newMtDir, FTI_Topo.sectorID, FTI_Topo.groupID);
        remove(buf);
        sprintf(str, "Creating metadata file (%s)...", buf);
        FTI_Print(str, FTI_DBUG);
        FILE *fd = fopen(buf, "w");
        if (fd != NULL) FTI_Print("Metadata file opened.", FTI_DBUG);
        else return FTI_NSCS;
        iniparser_dump_ini(ini, fd); // Write metadata
        if (fflush(fd) == 0) FTI_Print("Metadata file flushed.", FTI_DBUG);
        else return FTI_NSCS;
        if (fclose(fd) == 0) FTI_Print("Metadata file closed.", FTI_DBUG);
        else return FTI_NSCS;
        iniparser_freedict(ini);
    }
    free(fnl);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It erases the previous checkpoints and their metadata.
    @param      level           Level of cleaning.
    @param      group           Group ID of the cleanning target process.
    @param      rank            Rank of the cleanning target process.
    @return     integer         FTI_SCES if successfull.

    This function erases previous checkpoint depending on the level of the
    current checkpoint. Level 5 means complete clean up. Level 6 means clean
    up local nodes but keep last checkpoint data and metadata in the PFS.

 **/
/*-------------------------------------------------------------------------*/
int FTI_Clean(int level, int group, int rank) {
    char buf[FTI_BUFS];
    sprintf(buf, "Clean function called with level %d, group %d and rank %d.", level, group, rank); FTI_Print(buf, FTI_DBUG);
    if (level != 6) {
        snprintf(buf, FTI_BUFS, "%s/sector%d-group%d.fti",FTI_Conf.oldMtDir, FTI_Topo.sectorID, group); remove(buf);
        rmdir(FTI_Conf.oldMtDir);
    }
    if (level == 1 || level == 4 || level == 5 || level == 6) {
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Rank%d.fti",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID-1, rank); remove(buf);
        rmdir(FTI_Ckpt.oldL1Dir);
    }
    if (level == 2 || level == 5 || level == 6) {
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Rank%d.fti",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID-1, rank); remove(buf);
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Pcof%d.fti",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID-1, rank); remove(buf);
        rmdir(FTI_Ckpt.oldL1Dir);
    }
    if (level == 3 || level == 5 || level == 6) {
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Rank%d.fti",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID-1, rank); remove(buf);
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Rank%d.fti.enc",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID-1, rank); remove(buf);
        rmdir(FTI_Ckpt.oldL1Dir);
    }
    if (level == 4 || level == 5 || level == 6) {
        snprintf(buf, FTI_BUFS, "%s/Ckpt%d-Rank%d.fti",FTI_Ckpt.oldL4Dir, FTI_Ckpt.l4LastCkpt, rank);
        remove(buf);
        rmdir(FTI_Ckpt.newL4Dir);
        rmdir(FTI_Ckpt.oldL4Dir);
    }
    if (level == 5) { // If it is the very last cleaning
        rmdir(FTI_Ckpt.l1Dir);
        rmdir(FTI_Ckpt.l4Dir);
        snprintf(buf, FTI_BUFS, "%s/Topology.fti",FTI_Conf.metaDir); remove(buf);
        rmdir(FTI_Conf.metaDir);
    }
    if (level == 6) rmdir(FTI_Ckpt.l1Dir);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      It listens for checkpoint notifications.
    @return     integer         FTI_SCES if successfull.

    This function listens for notifications from the application processes
    and take the required actions after notification. This function is only
    executed by the head of the nodes.

 **/
/*-------------------------------------------------------------------------*/
int FTI_Listen() {
    MPI_Status status;
    char str[FTI_BUFS];
    int i, buf, flags[6];
    while (1) { // Each loop is a checkpoint interval
        for (i = 0; i < 6; i++) flags[i] = 0;
        FTI_Print("Head listening...", FTI_DBUG);
        for(i = 0; i < FTI_Topo.nbApprocs; i++) { // Iterate on the application processes in the node
            MPI_Recv(&buf, 1, MPI_INT, FTI_Topo.body[i], FTI_Conf.tag, FTI_Exec.globalComm, &status);
            sprintf(str, "The head received a %d message", buf); FTI_Print(str, FTI_DBUG);
            flags[buf-FTI_BASE] = flags[buf-FTI_BASE] + 1;
        }
        for (i = 1; i < 6; i++) if (flags[i] == FTI_Topo.nbApprocs) FTI_Exec.ckptLvel = i;
        if (FTI_Exec.ckptLvel == 5) break;
        if (FTI_CkptNotified() == FTI_SCES) FTI_Print("Checkpoint successfully done.", FTI_DBUG);
    }
    return FTI_SCES;
}


