
/*
 * Interface pour l'appel de la FTI apartir du Fortran 
 *
 * @Author : BOUI Faysal ( faysal.boui@yahoo.fr ) 
 * 
 */  

#include<mpi.h>
#include<fti.h>

void fti_init_(char *configFile,int *len,MPI_Fint *fti_comm,int *ierr){
	char* s;
	configFile[*len]='\0';
	*ierr = FTI_Init(configFile,MPI_COMM_WORLD);
	*fti_comm = MPI_Comm_c2f(FTI_COMM_WORLD);
}

void fti_protect_(int *id, void *ptr, long *size,int *ierr){
	*ierr = FTI_Protect(*id,ptr,*size);
}


void fti_snapshot_(int *ierr){
	*ierr = FTI_Snapshot();
}

void fti_finalize_(int *ierr){
	*ierr = FTI_Finalize();
}

