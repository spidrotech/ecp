/**
 *  @file   recover.c
 *  @author Leonardo A. Bautista Gomez (leobago@gmail.com)
 *  @date   July, 2013
 *  @brief  Recovery functions for the FTI library.
 */


#include "fti.h"


/*-------------------------------------------------------------------------*/
/**
    @brief      Decides wich action take depending on the restart level.
    @return     integer         FTI_SCES if successful.

    This function launchs the required action dependeing on the recovery
    level. The recovery level is detected from the checkpoint ID of the
    last checkpoint taken.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RecoverFiles() {
    int     i, fs, maxFs;
    char    str[FTI_BUFS];
    if (FTI_Topo.nbHeads == 1) i = 1; else i = 0;
    FTI_GetMeta(&fs, &maxFs, i, 0); // Getting last checkpoint ID
    sscanf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", &FTI_Exec.ckptID, &fs);
    FTI_Exec.ckptLvel = 1; // Check which level was the last checkpoint
    if ((FTI_Exec.ckptID) % FTI_Ckpt.l2CkptIntv == 0) FTI_Exec.ckptLvel = 2;
    if ((FTI_Exec.ckptID) % FTI_Ckpt.l3CkptIntv == 0) FTI_Exec.ckptLvel = 3;
    if ((FTI_Exec.ckptID) % FTI_Ckpt.l4CkptIntv == 0) FTI_Exec.ckptLvel = 4;
    FTI_Exec.lastCkptLvel = FTI_Exec.ckptLvel;
    FTI_Ckpt.l4LastCkpt = (FTI_Exec.ckptID/FTI_Ckpt.l4CkptIntv)*FTI_Ckpt.l4CkptIntv;
    if (FTI_Exec.reco == 2) FTI_Exec.ckptLvel = 4;
    if (FTI_Exec.reco == 2) FTI_Ckpt.l4LastCkpt = FTI_Exec.ckptID;
    sprintf(str, "The last checkpoint was level %d.", FTI_Exec.ckptLvel); FTI_Print(str, FTI_DBUG);
    if (!FTI_Topo.amIaHead) { // WARNING-TODO: Only taking into account the last saved checkpoint
        if (FTI_Exec.ckptLvel == 4) fs = FTI_RecoverL4(FTI_Topo.groupID);
        if (FTI_Exec.ckptLvel == 3) fs = FTI_RecoverL3(FTI_Topo.groupID);
        if (FTI_Exec.ckptLvel == 2) fs = FTI_RecoverL2(FTI_Topo.groupID);
        if (FTI_Exec.ckptLvel == 1) fs = FTI_RecoverL1(FTI_Topo.groupID);
        if (fs ==  FTI_SCES) FTI_Print("Recovery function finished successfully.", FTI_DBUG);
    }
    MPI_Barrier(FTI_Exec.globalComm); sleep(1); // Global barrier and sleep for clearer output
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Detects all the erasures for L1, L2 and L3.
    @param      fs              The ckpt. file size for this process.
    @param      maxFs           The max. ckpt. file size in the group.
    @param      group           The group ID.
    @param      erased          The array of erasures to fill.
    @return     integer         FTI_SCES if successful.

    This function detects all the erasures for L1, L2 and L3. It return the
    results in the erased array. The search for erasures is done at the
    three levels independently on the current recovery level.

 **/
/*-------------------------------------------------------------------------*/
int FTI_CheckErasures(unsigned long *fs, unsigned long *maxFs, int group, int *erased) {
    int         buf, i, j;
    char        str[FTI_BUFS], fn[FTI_BUFS];
    for (j = 0; j < FTI_Topo.groupSize*4; j++) erased[j] = 0;                   // Initialize erasures table
    FTI_GetMeta(fs, maxFs, group, 0);
    sprintf(fn, "%s/%s", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
    if (access(fn, F_OK) != 0) erased[FTI_Topo.groupRank] = 1;                          // Check L1
    buf = erased[FTI_Topo.groupRank];
    MPI_Allgather(&buf, 1, MPI_INT, erased, 1, MPI_INT, FTI_Exec.groupComm);
    sscanf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", &FTI_Exec.ckptID, &buf);
    sprintf(fn,"%s/Ckpt%d-Pcof%d.fti", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID, buf);
    if (access(fn, F_OK) != 0) erased[FTI_Topo.groupSize+FTI_Topo.groupRank] = 1;       // Check L2
    buf = erased[FTI_Topo.groupSize+FTI_Topo.groupRank];
    MPI_Allgather(&buf, 1, MPI_INT, erased+FTI_Topo.groupSize, 1, MPI_INT, FTI_Exec.groupComm);
    sprintf(fn, "%s/%s.enc", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
    if (access(fn, F_OK) != 0) erased[FTI_Topo.groupRank+(2*FTI_Topo.groupSize)] = 1;   // Check L3
    buf = erased[FTI_Topo.groupRank+(2*FTI_Topo.groupSize)];
    MPI_Allgather(&buf, 1, MPI_INT, erased+(2*FTI_Topo.groupSize), 1, MPI_INT, FTI_Exec.groupComm);
    sprintf(fn, "%s/%s", FTI_Ckpt.oldL4Dir, FTI_Exec.ckptFile);
    if (access(fn, F_OK) != 0) erased[FTI_Topo.groupRank+(3*FTI_Topo.groupSize)] = 1;   // Check L4
    buf = erased[FTI_Topo.groupRank+(3*FTI_Topo.groupSize)];
    MPI_Allgather(&buf, 1, MPI_INT, erased+(3*FTI_Topo.groupSize), 1, MPI_INT, FTI_Exec.groupComm);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Checks that all L1 ckpt. files are present.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function detects all the erasures for L1. If there is at least one,
    L1 is not considered as recoverable.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RecoverL1(int group) {
    int         erased[FTI_BUFS], buf, i, j; // FTI_BUFS > 32*3
    unsigned long fs, maxFs;
    FTI_CheckErasures(&fs, &maxFs, group, erased); // Checking erasures
    buf = 0; for(j = 0; j < FTI_Topo.groupSize; j++) if(erased[j]) buf++; // Counting erasures
    if (buf > 0) FTI_Print("Checkpoint files missing at L1.", FTI_EROR);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Recover L2 ckpt. files using the partner copy.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function tries to recover the L2 ckpt. files missing using the
    partner copy. If a ckpt. file and its copy are both missing, then we
    consider this checkpoint unavailable.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RecoverL2(int group) {
    int         erased[FTI_BUFS], gs, buf, j, src, dest;
    char        str[FTI_BUFS], lfn[FTI_BUFS], pfn[FTI_BUFS], *blBuf1, *blBuf2;
    unsigned long ps, fs, maxFs, pos = 0;
    FILE        *lfd, *pfd;
    MPI_Request reqSend, reqRecv;
    MPI_Status  status;
    blBuf1 = talloc(char, FTI_Conf.blockSize);
    blBuf2 = talloc(char, FTI_Conf.blockSize);
    gs = FTI_Topo.groupSize;
    src = FTI_Topo.left;
    dest = FTI_Topo.right;
    if (access(FTI_Ckpt.oldL1Dir, F_OK) != 0) mkdir(FTI_Ckpt.oldL1Dir, 0777);
    FTI_CheckErasures(&fs, &maxFs, group, erased); // Checking erasures
    buf = -1; for(j = 0; j < gs; j++) if(erased[j] && erased[((j+1)%gs)+gs]) buf=j; // Counting erasures
    sprintf(str, "A checkpoint file and its partner copy (ID in group : %d) have been lost", buf);
    if (buf > -1) FTI_Print(str, FTI_EROR);
    buf = 0; for(j = 0; j < gs*2; j++) if(erased[j]) buf++; // Counting erasures
    if (buf > 0) {
        ps = (maxFs/FTI_Conf.blockSize)*FTI_Conf.blockSize; pos = 0; // For the logic
        if (ps < maxFs) ps = ps + FTI_Conf.blockSize; // Calculating padding size
        sprintf(str,"File size: %ld, max. file size : %ld and padding size : %ld.", fs, maxFs, ps);
        FTI_Print(str, FTI_DBUG);
        if (erased[FTI_Topo.groupRank]) { // Open checkpoint file to recover
            sprintf(lfn,"%s/%s", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
            sprintf(str,"Opening checkpoint file (%s) to recover (L2).", lfn); FTI_Print(str, FTI_DBUG);
            lfd = fopen(lfn, "wb"); if (lfd == NULL) FTI_Print("R2 cannot open the checkpoint file.", FTI_EROR);
        }
        if (erased[src] && !erased[gs+FTI_Topo.groupRank]) { // Truncate and open partner file to transfer
            sscanf(FTI_Exec.ckptFile,"Ckpt%d-Rank%d.fti", &FTI_Exec.ckptID, &buf);
            sprintf(pfn,"%s/Ckpt%d-Pcof%d.fti", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptID, buf);
            sprintf(str,"Opening partner ckpt. file (%s) to transfer (L2).", pfn); FTI_Print(str, FTI_DBUG);
            if (truncate(pfn,ps) == -1) FTI_Print("R2 cannot truncate the partner ckpt. file.", FTI_EROR);
            pfd = fopen(pfn, "rb"); if (pfd == NULL) FTI_Print("R2 cannot open partner ckpt. file.", FTI_EROR);
        }
        while(pos < ps) { // Checkpoint files exchange
            if (erased[src] && !erased[gs+FTI_Topo.groupRank]) {
                fread(blBuf1, sizeof(char), FTI_Conf.blockSize, pfd);
                MPI_Isend(blBuf1, FTI_Conf.blockSize, MPI_CHAR, src, FTI_Conf.tag, FTI_Exec.groupComm, &reqSend);
            }
            if (erased[FTI_Topo.groupRank]) {
                MPI_Irecv(blBuf2, FTI_Conf.blockSize, MPI_CHAR, dest, FTI_Conf.tag, FTI_Exec.groupComm, &reqRecv);
            }
            if (erased[src] && !erased[gs+FTI_Topo.groupRank]) MPI_Wait(&reqSend, &status);
            if (erased[FTI_Topo.groupRank]) {
                MPI_Wait(&reqRecv, &status);
                if (fwrite(blBuf2, sizeof(char), FTI_Conf.blockSize, lfd) != FTI_Conf.blockSize)
                    FTI_Print("Errors writting the data in the R2 checkpoint file.", FTI_EROR);
            }
            pos = pos + FTI_Conf.blockSize;
        }
        if (erased[FTI_Topo.groupRank]) { // Close files
            if (fclose(lfd) != 0) FTI_Print("R2 cannot close the checkpoint file.", FTI_EROR);
            if (truncate(lfn,fs) == -1) FTI_Print("R2 cannot re-truncate the checkpoint file.", FTI_EROR);
        }
        if (erased[src] && !erased[gs+FTI_Topo.groupRank]) {
            if (fclose(pfd) != 0) FTI_Print("R2 cannot close the partner ckpt. file", FTI_EROR);
            if (truncate(pfn,fs) == -1) FTI_Print("R2 cannot re-truncate the partner ckpt. file.", FTI_EROR);
        }
    }
    free(blBuf1); free(blBuf2); // Free memory
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Recover L3 ckpt. files ordering the RS decoding algorithm.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function tries to recover the L3 ckpt. files missing using the
    RS decoding. If to many files are missing in the group, then we
    consider this checkpoint unavailable.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RecoverL3(int group) {
    int         erased[FTI_BUFS], gs, j, l = 0;
    unsigned long fs, maxFs;
    char        str[FTI_BUFS];
    gs = FTI_Topo.groupSize;
    if (access(FTI_Ckpt.oldL1Dir, F_OK) != 0) mkdir(FTI_Ckpt.oldL1Dir, 0777);
    FTI_CheckErasures(&fs, &maxFs, group, erased); // Checking erasures
    l = 0; for(j = 0; j < gs; j++) { if(erased[j]) l++; if(erased[j+(2*gs)]) l++; } // Counting erasures
    if (l > gs) FTI_Print("Too many erasures at L3.", FTI_EROR);
    sprintf(str, "There are %d encoded/checkpoint files missing in this group.", l);
    if (l > 0) { FTI_Print(str, FTI_INFO); FTI_Decode(fs, maxFs, erased); }// Reed-Solomon decoding
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Recover L4 ckpt. files from the PFS.
    @param      group           The group ID.
    @return     integer         FTI_SCES if successful.

    This function tries to recover the ckpt. files using the L4 ckpt. files
    stored in the PFS. If at least one ckpt. file is missing in the PFS, we
    consider this checkpoint unavailable.

 **/
/*-------------------------------------------------------------------------*/
int FTI_RecoverL4(int group) {
    unsigned long maxFs, fs, ps, pos = 0;
    int         j, l, gs, erased[FTI_BUFS];
    char        gfn[FTI_BUFS], lfn[FTI_BUFS], *blBuf1;
    FILE        *gfd, *lfd;
    blBuf1 = talloc(char, FTI_Conf.blockSize); // Allocate memory
    gs = FTI_Topo.groupSize;
    if (access(FTI_Ckpt.oldL1Dir, F_OK) != 0) mkdir(FTI_Ckpt.oldL1Dir, 0777);
    FTI_CheckErasures(&fs, &maxFs, group, erased); // Checking erasures
    l = 0; for(j = 0; j < gs; j++) { if(erased[j+(3*gs)]) l++; } // Counting erasures
    if (l > 0) FTI_Print("Checkpoint file missing at L4.", FTI_EROR);
    ps = (fs/FTI_Conf.blockSize)*FTI_Conf.blockSize; pos = 0; // For the logic
    if (ps < fs) ps = ps + FTI_Conf.blockSize; // Calculating padding size
    sprintf(gfn,"%s/%s", FTI_Ckpt.oldL4Dir, FTI_Exec.ckptFile); // Open and resize files
    sprintf(lfn,"%s/%s", FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
    if (access(gfn, R_OK) != 0) FTI_Print("R4 cannot read the checkpoint file in the PFS.", FTI_EROR);
    if (truncate(gfn,ps) == -1) FTI_Print("R4 cannot truncate the ckpt. file in the PFS.", FTI_EROR);
    gfd = fopen(gfn, "rb"); if (gfd == NULL) FTI_Print("R4 cannot open the ckpt. file in the PFS.", FTI_EROR);
    lfd = fopen(lfn, "wb"); if (lfd == NULL) FTI_Print("R4 cannot open the local ckpt. file.", FTI_EROR);
    while(pos < ps) { // Checkpoint files transfer from PFS
        fread(blBuf1, sizeof(char), FTI_Conf.blockSize, gfd);
        fwrite(blBuf1, sizeof(char), FTI_Conf.blockSize, lfd);
        pos = pos + FTI_Conf.blockSize;
    }
    fclose(gfd); fclose(lfd); // Close files
    if (truncate(gfn,fs) == -1) FTI_Print("R4 cannot re-truncate the checkpoint file in the PFS.", FTI_EROR);
    if (truncate(lfn,fs) == -1) FTI_Print("R4 cannot re-truncate the local checkpoint file.", FTI_EROR);
    free(blBuf1);
    return FTI_SCES;
}


/*-------------------------------------------------------------------------*/
/**
    @brief      Recover a set of ckpt. files using RS decoding.
    @return     integer         FTI_SCES if successful.

    This function tries to recover the L3 ckpt. files missing using the
    RS decoding.

 **/
/*-------------------------------------------------------------------------*/
int FTI_Decode(int fs, int maxFs, int *era) {
    int *matrix, *decMatrix, *dm_ids, *tmpmat, i, j, k, m, *erased, ps, bs, pos = 0;
    char **coding, **data, *dataTmp, fn[FTI_BUFS], efn[FTI_BUFS], str[FTI_BUFS];
    FILE *fd, *efd;
    bs = FTI_Conf.blockSize; k = FTI_Topo.groupSize; m = k;
    ps = ((maxFs/FTI_Conf.blockSize))*FTI_Conf.blockSize;
    if (ps < maxFs) ps = ps + FTI_Conf.blockSize; // Calculating padding size
    if (access(FTI_Ckpt.oldL1Dir, F_OK) != 0) mkdir(FTI_Ckpt.oldL1Dir, 0777);
    sprintf(fn,"%s/%s",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
    sprintf(efn,"%s/%s.enc",FTI_Ckpt.oldL1Dir, FTI_Exec.ckptFile);
    data = talloc(char *, k); coding = talloc(char *, m); dataTmp = talloc(char, FTI_Conf.blockSize*k);
    dm_ids = talloc(int, k); decMatrix = talloc(int, k*k); tmpmat = talloc(int, k*k); matrix =  talloc(int, k*k);
    erased = talloc(int, (k+m));
    if (FTI_CreateMatrix(matrix) == FTI_SCES) FTI_Print("Matrix created.", FTI_DBUG);
    for (i = 0; i < m; i++) {
        coding[i] = talloc(char, FTI_Conf.blockSize);
        data[i] = talloc(char, FTI_Conf.blockSize);
        erased[i] = era[i];
        erased[i+k] = era[i+(2*k)];
    }
    j = 0; for (i = 0; j < k; i++) { if (erased[i] == 0) {dm_ids[j] = i; j++;} }
    for (i = 0; i < k; i++) { // Building the matrix
        if (dm_ids[i] < k) {
            for (j = 0; j < k; j++) tmpmat[i*k+j] = 0;
            tmpmat[i*k+dm_ids[i]] = 1;
        } else for (j = 0; j < k; j++) { tmpmat[i*k+j] = matrix[(dm_ids[i]-k)*k+j]; }
    } // Inversing the matrix
    if (jerasure_invert_matrix(tmpmat, decMatrix, k, FTI_Ckpt.l3WordSize) < 0) FTI_Print("Error inversing matrix", FTI_EROR);
    if(erased[FTI_Topo.groupRank] == 0) { // Resize and open files
        if (truncate(fn,ps) == -1) FTI_Print("Error with truncate on checkpoint file", FTI_EROR);
        fd = fopen(fn, "rb"); efd = fopen(efn, "rb");
    } else { fd = fopen(fn, "wb"); efd = fopen(efn, "wb"); }
    if (fd == NULL) FTI_Print("R3 cannot open checkpoint file.", FTI_EROR);
    if (efd == NULL) FTI_Print("R3 cannot open encoded ckpt. file.", FTI_EROR);
    while(pos < ps) { // Main loop, block by block
        if(erased[FTI_Topo.groupRank] == 0) { // Reading the data
            fread(data[FTI_Topo.groupRank]+0, sizeof(char), bs, fd);
            fread(coding[FTI_Topo.groupRank]+0, sizeof(char), bs, efd);
        } else { bzero(data[FTI_Topo.groupRank], bs); bzero(coding[FTI_Topo.groupRank], bs); } // Erasure found
        MPI_Allgather(data[FTI_Topo.groupRank]+0, bs, MPI_CHAR, dataTmp, bs, MPI_CHAR, FTI_Exec.groupComm);
        for (i = 0; i < k; i++) memcpy(data[i]+0, &(dataTmp[i*bs]), sizeof(char)*bs);
        MPI_Allgather(coding[FTI_Topo.groupRank]+0, bs, MPI_CHAR, dataTmp, bs, MPI_CHAR, FTI_Exec.groupComm);
        for (i = 0; i < k; i++) memcpy(coding[i]+0, &(dataTmp[i*bs]), sizeof(char)*bs);
        if (erased[FTI_Topo.groupRank]) // Decoding the lost data work
            jerasure_matrix_dotprod(k, FTI_Ckpt.l3WordSize, decMatrix+(FTI_Topo.groupRank*k), dm_ids, FTI_Topo.groupRank, data, coding, bs);
        MPI_Allgather(data[FTI_Topo.groupRank]+0, bs, MPI_CHAR, dataTmp, bs, MPI_CHAR, FTI_Exec.groupComm);
        for (i = 0; i < k; i++) memcpy(data[i]+0, &(dataTmp[i*bs]), sizeof(char)*bs);
        if (erased[FTI_Topo.groupRank + k]) // Finally, re-encode any erased encoded checkpoint file
            jerasure_matrix_dotprod(k, FTI_Ckpt.l3WordSize, matrix+(FTI_Topo.groupRank*k), NULL, FTI_Topo.groupRank+k, data, coding, bs);
        if (erased[FTI_Topo.groupRank]) fwrite(data[FTI_Topo.groupRank]+0, sizeof(char), bs, fd);
        if (erased[FTI_Topo.groupRank + k]) fwrite(coding[FTI_Topo.groupRank]+0, sizeof(char), bs, efd);
        pos = pos + bs;
    }
    fclose(fd); fclose(efd); // Closing files
    if (truncate(fn,fs) == -1) FTI_Print("Error with truncate on ckpt file", FTI_EROR);
    free(tmpmat); free(erased); free(dm_ids); free(decMatrix); free(matrix); free(data); free(dataTmp); free(coding);
    return FTI_SCES;
}

