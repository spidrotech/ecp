#!/bin/bash

ALLTYPES="INTEGER REAL CHARACTER LOGICAL complex"
ALLKINDS="4 8"
MAXDIM="5"

cat<<CODE1_END
MODULE FTI
	
	use :: ISO_C_BINDING
	
	INTERFACE FTI_Protect_Fortran
	
CODE1_END

for T in ${ALLTYPES}; do
	if [ "${T}" = "REAL" ] || [ "${T}" = "complex" ]; then
		for K in ${ALLKINDS}; do
			echo "		MODULE PROCEDURE FTI_Protect_Fortran_${T}_K${K} "
			for D in $(seq 1 $MAXDIM); do
				echo "		MODULE PROCEDURE FTI_Protect_Fortran_${T}_K${K}_D${D}"
			done
		done
	else
		echo "		MODULE PROCEDURE FTI_Protect_Fortran_${T}"
		for D in $(seq 1 $MAXDIM); do
			echo "		MODULE PROCEDURE FTI_Protect_Fortran_${T}_D${D}"
		done
	fi
done

cat<<CODE2_END
		MODULE PROCEDURE FTI_Protect_Fortran_Ptr

	END INTERFACE FTI_Protect_Fortran
	
	CONTAINS
		SUBROUTINE FTI_Init_Fortran(config_File,FTI_Comm,ierr)
			CHARACTER(len=32) :: config_File
			INTEGER :: l,FTI_Comm,ierr
			CALL FTI_Init(config_File,len(trim(config_File)),FTI_Comm,ierr)
		END SUBROUTINE FTI_Init_Fortran
		
		SUBROUTINE FTI_Snapshot_Fortran(ierr)
			INTEGER :: ierr
			CALL FTI_Snapshot(ierr)
		END SUBROUTINE FTI_Snapshot_Fortran
		
		SUBROUTINE FTI_Finalize_Fortran(ierr)
			INTEGER :: ierr
			CALL FTI_Finalize(ierr)
		END SUBROUTINE FTI_Finalize_Fortran
		
		SUBROUTINE FTI_Protect_Fortran_Ptr(id_F, ptr,size_F,ierr)
			INTEGER :: id_F,size_F,ierr
			TYPE(c_ptr) :: ptr
			CALL FTI_Protect(id_F,ptr,size_F,ierr)
		END SUBROUTINE FTI_Protect_Fortran_Ptr

CODE2_END

for T in ${ALLTYPES}; do
	if [ "${T}" = "REAL" ] || [ "${T}" = "complex" ]; then
		for K in ${ALLKINDS}; do
			echo "		SUBROUTINE FTI_Protect_Fortran_${T}_K${K}(id_F, ptr,ierr) "
			echo "			INTEGER :: id_F,ierr"
			echo "			${T}(KIND=${K}) :: ptr"
			echo "			CALL FTI_Protect(id_F,ptr,sizeof(ptr),ierr)"
			echo "		END SUBROUTINE FTI_Protect_Fortran_${T}_K${K}"
			echo""
			
			for D in $(seq 1 $MAXDIM); do
				echo "		SUBROUTINE FTI_Protect_Fortran_${T}_K${K}_D${D}(id_F, ptr,ierr) "
				echo "			INTEGER :: id_F,ierr"
				echo -n "			${T}(KIND=${K}) ,DIMENSION("
				for P in $(seq 1 ${D});do
					if [ "${P}" = "1" ]; then 
						echo -n ":"
					else
						echo -n ",:"
					fi
				done
				echo ") :: ptr"
				echo "			CALL FTI_Protect(id_F,ptr,sizeof(ptr),ierr)"
				echo "		END SUBROUTINE FTI_Protect_Fortran_${T}_K${K}_D${D}"
				echo""
			done
		done
	else
		echo "		SUBROUTINE FTI_Protect_Fortran_${T}(id_F, ptr,ierr) "
		echo "			INTEGER :: id_F,ierr"
		echo "			${T} :: ptr"
		echo "			CALL FTI_Protect(id_F,ptr,sizeof(ptr),ierr)"
		echo "		END SUBROUTINE FTI_Protect_Fortran_${T}"
		echo""
		
		for D in $(seq 1 $MAXDIM); do
			echo "		SUBROUTINE FTI_Protect_Fortran_${T}_D${D}(id_F, ptr,ierr) "
			echo "			INTEGER :: id_F,ierr"
			echo -n "			${T} ,DIMENSION("
			for P in $(seq 1 ${D});do
				if [ "${P}" = "1" ]; then 
					echo -n ":"
				else
					echo -n ",:"
				fi
			done
			echo ") :: ptr"
			echo "			CALL FTI_Protect(id_F,ptr,sizeof(ptr),ierr)"
			echo "		END SUBROUTINE FTI_Protect_Fortran_${T}_D${D}"
			echo""
		done
	fi
done

cat<<CODE3_END

	END MODULE fti

CODE3_END
