/**
 * \file main.c
 * \brief TEST PLUGIN
*/
#include <stdio.h>
#include "mock.h"

#pragma instrumente function (mock1,mock2,mock2,mock3,mock5)
void mock1() {
	printf("mock1\n");
}

void mock2() {
	printf("mock2\n");
}

void mock3() {
	printf("mock3\n");
}

void mock4() {
	printf("mock4\n");
}
