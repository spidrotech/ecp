#ifndef __TEST__H
#define __TEST__H

void mock1();
void mock2();
void mock3();
void mock4();

#endif
