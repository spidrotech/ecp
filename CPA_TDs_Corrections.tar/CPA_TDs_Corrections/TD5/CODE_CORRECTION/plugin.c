#include <stdlib.h>
// Pour les plugins
#include "gcc-plugin.h"
#include "function.h"
#include "cpplib.h"
#include "vec.h"
#include "tree.h"
#include <tree-pass.h>
#include <gimple.h>
#include <string.h>

#define FUNC_TABLE_SIZE 256

/* Global variable */
typedef char *my_char_p;
DEF_VEC_P(my_char_p);
DEF_VEC_ALLOC_P(my_char_p,heap);
static VEC(my_char_p,heap) *list_of_functions;

#define GCC_BAD(gmsgid) \
  do { warning (OPT_Wpragmas, gmsgid); return; } while (0)


/* USED TO CHECK GPL COMPATIBILITY, CAN T COMPILE WITHOUT IT */ 
int plugin_is_GPL_compatible;

/* CHECK IF FUNCTION NAME WAS ALREADY PUSHED */
static int already_pushed(const char* str) {
        char *name;
        unsigned ix;

	if (VEC_length(my_char_p, list_of_functions)) {
        	FOR_EACH_VEC_ELT_REVERSE (my_char_p, list_of_functions, ix, name)
        	{
			if(strcmp (name, str) == 0) return 1;
        	}
	}

	return 0;
}

/* REMOVE FUNCTION NAME IN THE GLOBAL LIST */
static void remove_name(const char* str) {
        char *name;
        unsigned int ix;
	if (VEC_length(my_char_p, list_of_functions)) {
        	FOR_EACH_VEC_ELT_REVERSE (my_char_p, list_of_functions, ix, name)
        	{
			if(strcmp (name, str) == 0) {
				VEC_ordered_remove(my_char_p, list_of_functions,ix);
			}
        	}
	}
}

static void handle_pragma_function2 (struct cpp_reader *ARG_UNUSED(dummy)) {
	printf("Handling pragma function2\n");
	enum cpp_ttype token;
	tree x;
	bool close_paren_needed_p = false;

	// Check if pragma is not in a function
	if (cfun) {
		error ("#pragma instrumente function is not allowed inside functions");
		return;
	}

	token = pragma_lex (&x);

	if (token == CPP_OPEN_PAREN) {
		close_paren_needed_p = true;
		token = pragma_lex (&x);
	}
	if (token != CPP_NAME) {
		GCC_BAD ("%<#pragma instrumente function%> is not a string");
		return;
	} else {
		do {
			char *op = IDENTIFIER_POINTER (x);
			if (!already_pushed(op)) {
				VEC_safe_push (my_char_p, heap, list_of_functions, op);
			} else  {
				warning (OPT_Wpragmas, "already declared function %s", op); 
			}
			token = pragma_lex (&x);

			while (token == CPP_COMMA)
				token = pragma_lex (&x);
        	} while (token == CPP_NAME || token == CPP_STRING);

		if (close_paren_needed_p) {
			if (token == CPP_CLOSE_PAREN)
				token = pragma_lex (&x);
			else
				GCC_BAD ("%<#pragma instrumente function(string" 
					"[,string]...)%> does not have a final %<)%>");
        }

      if (token != CPP_EOF)
        {
          error ("#pragma instrumente function string... is badly formed");
          return;
        }
    }
}

static void register_my_pragma (void *event_data, void *data) {
	c_register_pragma ("instrumente", "function", handle_pragma_function2);
}

/* Pass function */
unsigned int mihps_exec() {
	const char *fname = gimple_decl_printable_name( cfun->decl, 3);
	printf("MIHPS pass is running on %s\n", fname);

	return 0;
}

/* Define plugin informations */
static struct plugin_info mihps_plugin_infos =
{
        .version = "0.1a",
        .help = "Pragmas"
};


bool mihps_gate() {
	const char *fname = gimple_decl_printable_name( cfun->decl, 3);
	if (already_pushed(fname)) {
		remove_name(fname);
		return true;
	} else {
		return false;
	}
}

void plugin_finalize(void *gcc_data, void *user_data) {
	if (VEC_length(my_char_p, list_of_functions)) {
		char *name;
		unsigned int ix;
	        FOR_EACH_VEC_ELT_REVERSE (my_char_p, list_of_functions, ix, name)
        	{
			warning (OPT_Wpragmas, "argument %s not used (function is not defined)", name);
        	}	
	}
	// FREE VECT
}

/* Define a new gimple pass ==> see tree_pass.h */
static struct opt_pass own_pragma_pass =
{
        .type = GIMPLE_PASS,
        .name = "Own Pragma pass",
        .gate = mihps_gate,
        .execute = mihps_exec
};

int plugin_init (struct plugin_name_args *plugin_info,
                  struct plugin_gcc_version *version) {

	printf("Loading Plugin MIHPS...\n");

	/* Check GCC version */
	if( strncmp( version->basever, "4.7", strlen("4.7") ) ){
		if( strncmp( version->basever, "4.6", strlen( "4.6" ) ) ){
			printf("Error bad GCC version (%s) instead of 4.{6,7}.*\n",
				version->basever);
			return -1;
		}
	}

	/* Fill in new pass informations */
	struct register_pass_info new_pass;

	new_pass.pass = &own_pragma_pass;
	new_pass.reference_pass_name = "cfg";
	new_pass.ref_pass_instance_number = 1;
	new_pass.pos_op = PASS_POS_INSERT_AFTER;

	/* Register the pass */
	register_callback(plugin_info->base_name, PLUGIN_PASS_MANAGER_SETUP,
		NULL,  &new_pass);

	/* Register plugin infos */
	register_callback(plugin_info->base_name, PLUGIN_INFO, NULL, &mihps_plugin_infos);

	/* Register a callback for cleanup */
	register_callback(plugin_info->base_name, PLUGIN_FINISH, plugin_finalize, NULL);

	/* Handling Pragmas */
	list_of_functions = VEC_alloc (my_char_p, heap, FUNC_TABLE_SIZE);
	register_callback (plugin_info->base_name, PLUGIN_PRAGMAS,
		register_my_pragma, NULL);

	return 0;
}
