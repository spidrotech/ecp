/**
 * \file main.c
 * \brief TEST PLUGIN
*/
#include <stdio.h>
#include "mock.h"

int main (int argc, char **argv) {

	printf("begining main\n");
	mock1();
	printf("ending main\n");

	return 0;
}
