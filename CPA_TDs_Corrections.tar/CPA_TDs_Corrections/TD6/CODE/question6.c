#include <stdio.h>
#include <stdlib.h>

void mafonction()
{
	int i, j;
	for( i=0; i<10; i++)
		for (j=0; j<10; j++)
		{
			printf("toto");
		}
}

int main (int argc, char * argv[])
{
	mafonction();
	return 0;
}
