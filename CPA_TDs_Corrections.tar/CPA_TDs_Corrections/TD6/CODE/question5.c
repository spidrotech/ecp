#include <stdio.h>
#include <stdlib.h>

void mafonction()
{
	int i, j;
	for( i=0; i<1000; i++)
	{
		printf("ToTo %d", i);
		for (j=0; j<1000; j++)
		{
			printf("TATA %d", j);
		}
	}
}

int main (int argc, char * argv[])
{
	mafonction();
	return 0;
}
