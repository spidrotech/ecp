#ifndef __COMPUTE__H
#define __COMPUTE__H

void compute (unsigned int matrix_dim,
		unsigned int repeat);

#endif
