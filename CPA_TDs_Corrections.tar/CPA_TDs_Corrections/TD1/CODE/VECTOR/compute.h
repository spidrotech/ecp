#ifndef __COMPUTE__H
#define __COMPUTE__H

void print_results(unsigned int *v1,
			unsigned int *v2,
			unsigned int *v3,
			unsigned int size);

void compute (unsigned int vector_size,
		unsigned int repeat);

#endif
