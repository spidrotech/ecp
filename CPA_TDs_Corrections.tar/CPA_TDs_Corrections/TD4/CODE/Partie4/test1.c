#include <stdio.h>

void foo( int n )
{
	int i;

	for( i = 0 ; i < n ; i++ )
	{
		printf("Iteration %d\n", i );
	}


}


int main( int argc, char **argv )
{

	foo( 5 );
	return 0;
}
