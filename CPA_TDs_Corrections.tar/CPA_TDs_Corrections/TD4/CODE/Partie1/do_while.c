#include <stdio.h>




int main( int argc, char **argv )
{

	int i = 0;

	do
	{
		i++;
	}while( i < 100 );


	return 0;
}
