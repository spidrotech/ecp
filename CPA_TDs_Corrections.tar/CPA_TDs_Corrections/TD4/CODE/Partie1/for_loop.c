#include <stdio.h>




int main( int argc, char **argv )
{

	int i,a; 

	for( i = 0 ; i < 50000 ; i++ )
	{
		a = i;
	}

	return 0;
}
