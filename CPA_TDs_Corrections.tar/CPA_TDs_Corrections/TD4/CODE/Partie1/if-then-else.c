#include <stdio.h>




int main( int argc, char **argv )
{
	int i;
	if(argc == 5 )
	{
		i = 1;
	}
	else
	{
		i = 2;
	}
	
	return 0;
}
