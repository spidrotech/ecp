#include <stdio.h>




int main( int argc, char **argv )
{
	printf("coucou");
	return 0;
}
