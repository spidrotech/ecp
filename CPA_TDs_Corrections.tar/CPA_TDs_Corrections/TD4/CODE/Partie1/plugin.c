#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <gcc-plugin.h>
#include <tree-pass.h>
#include <basic-block.h>
#include <gimple.h>


FILE *out = NULL;

int plugin_is_GPL_compatible;

/* Define plugin informations */
static struct plugin_info mihps_plugin_infos =
{
	.version = "0.1a",
	.help = "Graphviz output of symbol table"
};


bool mihps_gate()
{
	/* You can do some checks here
	 * to enable or disable the pass */
	return true;
}


int op_uid = 0;

void unfold_tree_op( const_tree op, char *parent )
{
	int i;
	const_tree operand;
	char local_id[20];

	if( !op )
		return ;

	//printf("-------\n");	
	//printf("\t\t Tree node of code %s and class %s with %d operands\n", 
	//		tree_code_name[ TREE_CODE( op ) ], TREE_CODE_CLASS_STRING( TREE_CODE_CLASS( TREE_CODE( op ) ) ) , TREE_OPERAND_LENGTH( op ));
	//printf("-------\n");		
	//debug_tree( (tree)op );
	
	/* GRAPHVIZ ================================== */
	sprintf( local_id , "F%dOP%d", current_function_funcdef_no, op_uid++ );
	fprintf( out, "%s [label=\"OP %s::%s\" color=green]\n", local_id , tree_code_name[ TREE_CODE( op ) ], TREE_CODE_CLASS_STRING( TREE_CODE_CLASS( TREE_CODE( op ) ) ) );
	fprintf( out, " %s -> %s  [color=green]\n", parent, local_id );
	/* ============================================ */
	
	const char *data, *end;

	
	for( i = 0 ; i < TREE_OPERAND_LENGTH( op ) ; i++ )
	{
		operand = TREE_OPERAND( op, i );
		unfold_tree_op( operand, local_id );
	}

}

unsigned int mihps_exec()
{
	const char *fname = gimple_decl_printable_name( cfun->decl, 3 );
	printf("MIHPS pass is running on %s\n", fname);	

    basic_block bb;
    gimple_stmt_iterator gsi;
    gimple stmt;
    const_tree op;
    const_tree operand;
    int i = 0;

	/* Fill in uids as they initially contain garbage */
	FOR_ALL_BB(bb)
    {
		for (gsi=gsi_start_bb(bb); !gsi_end_p(gsi); gsi_next(&gsi))
		{
			stmt = gsi_stmt(gsi);
			gimple_set_uid(stmt, i++);
		}
	}

	/* GRAPHVIZ ================================== */
	fprintf(out, "F%d [label=\"%s\" shape=diamond]\n", current_function_funcdef_no, fname );
	fprintf(out, "F%d -> F%dBB0\n", current_function_funcdef_no, current_function_funcdef_no);
	/* ============================================ */
	
	/* Walk gimple tree */
    FOR_ALL_BB(bb)
    {
		/* GRAPHVIZ ================================== */
		char extra_BB[50];
		*extra_BB = '\0';
		
		if( ENTRY_BLOCK_PTR == bb )
			sprintf( extra_BB, "\\nENTRY_BLOCK");
		else if(  EXIT_BLOCK_PTR == bb )
			sprintf( extra_BB, "\\nEXIT_BLOCK");
		
		fprintf(out, "F%dBB%d [label=\"BB %d %s\" shape=circle color=blue] \n", current_function_funcdef_no, bb->index, bb->index, extra_BB );
		/* ============================================ */
		
		gimple prev_stmt = NULL;

		for (gsi=gsi_start_bb(bb); !gsi_end_p(gsi); gsi_next(&gsi))
		{
						
			stmt = gsi_stmt(gsi);
			
			/* GRAPHVIZ ================================== */
			fprintf(out, "F%dG%d [label=\"%s @ %s:%d UID : %d\"] \n",current_function_funcdef_no, gimple_uid( stmt ), gimple_code_name[gimple_code(stmt)], gimple_filename (stmt), gimple_lineno(stmt), gimple_uid(stmt) );
			fprintf(out, "F%dBB%d -> F%dG%d [color=blue]\n", current_function_funcdef_no, bb->index, current_function_funcdef_no, gimple_uid( stmt ) );
			
			if( prev_stmt )
				fprintf(out, "F%dG%d -> F%dG%d\n", current_function_funcdef_no, gimple_uid( prev_stmt ) , current_function_funcdef_no, gimple_uid( stmt ) );
			/* ============================================ */

			//printf("=====================================\n");	
			//printf("\tThis is a statement of type %s with %d ops @ %s:%d\n", gimple_code_name[gimple_code(stmt)], gimple_num_ops(stmt), gimple_filename (stmt), gimple_lineno(stmt) );
			//printf("=====================================\n");		
			//debug_gimple_stmt( stmt );
			

			prev_stmt = stmt;
			

			/* Unfold TREE */
			for( i = 0 ; i < gimple_num_ops(stmt) ; i++ )
			{
				op = gimple_op (stmt, i);
				
				if( !op )
					continue;
				
				char parent[20];
				/* GRAPHVIZ ================================== */
				sprintf( parent, "F%dG%d",  current_function_funcdef_no, gimple_uid( stmt ));
				/* ============================================ */

				unfold_tree_op( op , parent );
			
			}

		}
		
		
		/* Walk BB edges */
		edge target;
		edge_iterator edge_it;
		
		FOR_EACH_EDGE(target,edge_it,bb->succs)
		{
			/* GRAPHVIZ ================================== */
			fprintf(out, "F%dBB%d -> F%dBB%d [color=red]\n", current_function_funcdef_no, bb->index, current_function_funcdef_no, target->dest->index );
			/* ============================================ */
		}
		
		
	}
	

	return 0;
}

/* Define a new gimple pass ==> see tree_pass.h */
static struct opt_pass graphviz_symb_pass = 
{
	.type = GIMPLE_PASS,
	.name = "Graphviz Symbol Table", 
	.gate = mihps_gate,
	.execute = mihps_exec
};

void plugin_release(void *gcc_data, void *user_data)
{
	/* GRAPHVIZ ================================== */
	if( !out )
		return;

	fprintf(out,"\n}\n");
	fclose( out );
	out = NULL;
	/* ============================================ */
}

int plugin_init (struct plugin_name_args *plugin_ctx,
		struct plugin_gcc_version *version)
{
	/* GRAPHVIZ ================================== */
	
	/* Generate an unique graph name */
	char name[100];
	sprintf(name, "graph-XXXXXX");
	if( !strcmp( mktemp(name), "") )
		return 1;
		
	strcat( name, ".dot");
	/* Open graphviz output file */
	out = fopen(name, "w");
	
	fprintf(out,"Digraph G{\n");
	/* ============================================ */

	printf("Loading Plugin MIHPS...\n");

	/* Check GCC version */
	if( strncmp( version->basever, "4.7", strlen("4.7") ) ) 
	{
		if( strncmp( version->basever, "4.6", strlen( "4.6" ) ) )
		{
			printf("Error bad GCC version (%s) instead of 4.{6,7}.*\n",
				version->basever);
			return -1;
		}
	}


	/* Fill in new pass informations */
	struct register_pass_info new_pass;

	new_pass.pass = &graphviz_symb_pass;
	new_pass.reference_pass_name = "cfg";
	new_pass.ref_pass_instance_number = 1;
	new_pass.pos_op = PASS_POS_INSERT_AFTER;

	/* Register the pass */
	register_callback(plugin_ctx->base_name, PLUGIN_PASS_MANAGER_SETUP,
			  NULL,  &new_pass );

	/* Register plugin infos */
	register_callback(plugin_ctx->base_name, PLUGIN_INFO, NULL, &mihps_plugin_infos );

	/* Register a callback for cleanup */
	register_callback(plugin_ctx->base_name, PLUGIN_FINISH, plugin_release, NULL );

	return 0;
}

