#include <stdio.h>




int main( int argc, char **argv )
{

	int i = 0;

	while( i < 100 )
	{
		i++;
	};


	return 0;
}
