#include <stdio.h>






void mihps_profiler_enter( char *func, unsigned int id )
{
	printf("LIB : %s === Id : %d\n", func, id);
}



void mihps_profiler_leave( char *func, unsigned int id )
{
	printf("LIB : %s  === Id : %d\n", func, id );
}
