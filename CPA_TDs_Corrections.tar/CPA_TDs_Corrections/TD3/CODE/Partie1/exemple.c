#include <stdio.h>
#include <stdlib.h>

int mafonction(int n)
{
	int x = n*2;
	{
		int n=0, x;
		x = n*3;
	}

	return x;
}



int main( int argc, char * argv[])
{
	int ret = 0;

	ret = mafonction(3);
	printf("mafonction(3) = %d\n", ret);

	return 0;
}
