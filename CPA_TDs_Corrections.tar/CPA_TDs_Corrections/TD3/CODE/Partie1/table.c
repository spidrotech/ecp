#include <stdio.h>
#include <stdlib.h>

typedef struct{
	int uid;
	int context_uid;
	int pos;
	void * addr;
	char type[32];
	char name[128];
} symbol;





void entree_contexte(int uid)
{

}

int nouvelle_variable(char * type, char * name)
{
	int uid = -1;



	return uid;
}

symbol recherche_variable(char * name)
{

}

int sortie_contexte()
{
	int uid = -1;


	return uid;
}
