#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <gcc-plugin.h>
#include <tree-pass.h>
#include <basic-block.h>
#include <gimple.h>
#include <c-family/c-common.h>
#include <cfgloop.h>

int plugin_is_GPL_compatible;

/* Define plugin informations */
static struct plugin_info mihps_plugin_infos =
{
	.version = "0.1a",
	.help = "MIHPS instrumentation pass"
};


bool mihps_profiler_gate()
{
	/* You can do some checks here
	 * to enable or disable the pass */
	return true;
}


 /* Loop handling */
 
 int get_number_of_iterations( struct loop *loop )
 {
	 if( loop->any_upper_bound )
	 {
		 int number = double_int_to_uhwi(loop->nb_iterations_upper_bound);
		 if( number == INT_MAX )
			return -1;
		 else
			return number;
	 }
	else
		return -1;
 }
 

void tag_loops_empty()
{
	basic_block bb;
	gimple_stmt_iterator gsi;
	gimple stmt;

	/* Fill in uids as they initially contain garbage */
	FOR_ALL_BB(bb)
	{
		for (gsi=gsi_start_bb(bb); !gsi_end_p(gsi); gsi_next(&gsi))
		{
			stmt = gsi_stmt(gsi);
			/* We use the uid to store the weight of each statement */
			gimple_set_uid(stmt, 1);
		}
	}
}


void _tag_loop(struct loop *loop, int pow)
{
	gimple_stmt_iterator gsi;
	gimple stmt;
	int it = get_number_of_iterations( loop );
	
	/* This function goes down the loop tree */

	if( 0 < it )
	{
		basic_block * body = get_loop_body (loop);
		
		printf("Found a loop with %d it in bb %d\n", it, (*body)->index);

		pow *= it;

		for (gsi=gsi_start_bb(*body); !gsi_end_p(gsi); gsi_next(&gsi))
		{
			stmt = gsi_stmt(gsi);
			/* We use the uid to store the weight of each statement */
			gimple_set_uid(stmt, pow );
		}

	}
	
	/* Lets go down the loop tree ! */
	struct loop *inner;
	for ( inner=loop->inner; inner!=NULL; inner=inner->next )
	{
		printf("Inner loop\n");
		_tag_loop( inner, pow );
	}
}


void tag_loops()
{
	struct loop *loop;
	loop_iterator li;

	/* Set All uids to 1 */
	tag_loops_empty();
	printf("About to process loops\n");
	/* Compute higher uids which are within loops */  
	_tag_loop( current_loops->tree_root, 1 );

}
 
int iload = 0, istore = 0;
int fload = 0, fstore = 0;
int iops = 0, fops = 0;


enum op_ctx
{
	OP_READ,
	OP_WRITE
};


bool is_real( tree op )
{
	if( !op )
		return false;

	if( (TREE_CODE( op ) == REAL_TYPE) || (TREE_CODE( op ) == REAL_CST ))
	{
		return true;
	}

	return false;
}


void hit_op( tree op, enum op_ctx ctx, int weight )
{

	if( ctx == OP_READ )
	{

		if( is_real( op ) )
		{
			fload+=weight;
		}
		else
		{
			iload+=weight;
		}
	}
	else
	{

		if( is_real( op ) )
		{
			fstore+=weight;
		}
		else
		{
			istore+=weight;
		}
	}
}



void unfold_op( tree op, enum op_ctx ctx, int weight )
{
	switch( TREE_CODE( op ) )
	{
		case VAR_DECL:
		case PARM_DECL:
		case CONST_DECL:
		case INTEGER_CST:
		case REAL_CST:
		case STRING_CST:
		case SSA_NAME:
		case MEM_REF:
		case ADDR_EXPR:
			hit_op( op, ctx, weight );
		break;
		case ARRAY_REF:
			/* Array ref are read only => only the effective adress is written */
			unfold_op( TREE_OPERAND(op,0), OP_READ, weight ); /* array base */
			unfold_op( TREE_OPERAND(op,1), OP_READ, weight ); /* array index */
			/* Signal action on effective target */
			unfold_op( TREE_OPERAND(op,0), ctx, weight );
		break;

		default :
			printf("WARNING operation Not handled : %s\n", tree_code_name[TREE_CODE( op )] );
	}
	
	/* Recursive process */
	int i;
	for( i = 0 ; i < TREE_OPERAND_LENGTH( op ) ; i++ )
	{
		tree operand = TREE_OPERAND( op, i );
		
		if( !operand )
			continue;
		
		unfold_op( operand, ctx, weight );
	}
}



void count_ops()
{
	basic_block bb;
	gimple_stmt_iterator gsi;
	gimple stmt;
	int i;
	
	/* Set loops weights in uids */
	tag_loops();

	/* Fill in uids as they initially contain garbage */
	FOR_ALL_BB(bb)
	{
		for (gsi=gsi_start_bb(bb); !gsi_end_p(gsi); gsi_next(&gsi))
		{
			stmt = gsi_stmt(gsi);
			int weight = gimple_uid( stmt );
			
			/* Process each type individually */
			switch( gimple_code( stmt ) )
			{
				case GIMPLE_ASSIGN :
					/* Unfold LHS */
					unfold_op( gimple_op(stmt,0), OP_WRITE, weight );
					/* Unfold RHS 1 */
					tree type1 = TREE_TYPE (gimple_op (stmt, 1));
					unfold_op( gimple_op(stmt,1), OP_READ, weight );
					
					tree type2 = NULL;
					/* Unfold RHS 2 */
					if( 2 < gimple_num_ops( stmt ) )
					{
						unfold_op( gimple_op(stmt,2), OP_READ, weight );
				
						/* Update ops */
						
						type2 = TREE_TYPE (gimple_op (stmt, 2));

						if (TREE_CODE (type2) == REAL_TYPE)
							type1 = type2;
						}
						
						if( is_real(type1) || is_real( type2 ) )
						{
							fops += weight;
						}
						else
						{
							iops += weight;
						}

				break;
				case GIMPLE_CALL :
				      for ( i=0; i<gimple_call_num_args(stmt); i++ )
					  {
						  unfold_op( gimple_call_arg(stmt,i), OP_READ, weight );
					  }
				break;
				case GIMPLE_COND :
					unfold_op( gimple_cond_lhs(stmt), OP_READ, weight );
					unfold_op( gimple_cond_rhs(stmt), OP_READ, weight );
				break;
			}
		}
	}
	
	
}

 enum insert_pos
 {
	 PR_INS_START,
	 PR_INS_END
 };
 
 

void add_profiling_call(basic_block bb, enum insert_pos pos)
{
	gimple_stmt_iterator gsi;
	gimple call;

	const char * fname = gimple_decl_printable_name( cfun->decl, 0 );


	/* Setup profiling function type */
	/* void mihps_profile_{enter|leave}( char *, unsigned int ) */
	tree pftype = build_function_type_list( void_type_node, ptr_type_node, unsigned_type_node, NULL_TREE );
	tree pfunc = build_fn_decl( (pos==PR_INS_START)?"mihps_profiler_enter":"mihps_profiler_leave", pftype );

	/* Build function name */
	tree fname_tree = fix_string_type( build_string (strlen( fname ) + 1, fname) );
	tree ptrtype = build_pointer_type (TREE_TYPE (TREE_TYPE (fname_tree)));
	tree p_name = build1 (ADDR_EXPR, ptrtype, fname_tree);


	/* Build function ID */
	tree function_id = build_int_cst (unsigned_type_node, current_function_funcdef_no);

	call = gimple_build_call (pfunc, 2, p_name, function_id );

	printf("Inserting call\n");
	if( pos == PR_INS_START )
	{
		gsi=gsi_start_bb(bb);
		gsi_insert_before( &gsi , call, GSI_NEW_STMT);
	}
	else
	{
		gsi=gsi_last_bb(bb);
		gsi_insert_before( &gsi , call, GSI_NEW_STMT);	
	}

}

void insert_function_name(basic_block bb, enum insert_pos pos)
{
	gimple_stmt_iterator gsi;
	gimple printf_call;

	const char * fname = gimple_decl_printable_name( cfun->decl, 3 );
	
	/* Build printf format */
	tree format_tree = fix_string_type( build_string (strlen( "%s" ) + 1, "%s") );
	tree ptr_format = build_pointer_type (TREE_TYPE (TREE_TYPE (format_tree)));
	tree p_format = build1 (ADDR_EXPR, ptr_format, format_tree);
	
	/* Build function name */
	tree fname_tree = fix_string_type( build_string (strlen( fname ) + 1, fname) );
	tree ptrtype = build_pointer_type (TREE_TYPE (TREE_TYPE (fname_tree)));
	tree p_name = build1 (ADDR_EXPR, ptrtype, fname_tree);

	printf_call = gimple_build_call (built_in_decls[BUILT_IN_PRINTF], 2, p_format, p_name );

	printf("Inserting printf\n");
	if( pos == PR_INS_START )
	{
		gsi=gsi_start_bb(bb);
		gsi_insert_before( &gsi , printf_call, GSI_NEW_STMT);
	}
	else
	{
		gsi=gsi_last_bb(bb);
		gsi_insert_before( &gsi , printf_call, GSI_NEW_STMT);	
	}
}

unsigned int mihps_profiler_exec()
{
	const char * fname = gimple_decl_printable_name( cfun->decl, 3 );
	printf("MIHPS pass is running on %s\n", fname);	

    basic_block bb, new_bb;
    
    gimple stmt;
    const_tree op;
    const_tree operand;

	/* Walk BB edges */
	edge e;
	edge_iterator edge_it;

	
	FOR_EACH_BB(bb)
    {
		FOR_EACH_EDGE(e,edge_it,bb->preds)
		{
			if( e->src == ENTRY_BLOCK_PTR )
			{
				printf("BB %d one of my parents id ENTRY\n", bb->index);
				insert_function_name( bb , PR_INS_START);
				//add_profiling_call(bb , PR_INS_START);
			}
		
		}
		
		FOR_EACH_EDGE(e,edge_it,bb->succs)
		{
			if( e->dest == EXIT_BLOCK_PTR )
			{
				printf("BB %d one of my sucessor is EXIT\n", bb->index);
				insert_function_name( bb , PR_INS_END);
				//add_profiling_call(bb , PR_INS_END);
			}
		}
	}

	/* Process loops and count operations */
	 count_ops();

	printf("Function %s stats =============================\n", fname);
	printf("iload : %d istore : %d iops : %d\n", iload, istore, iops );
	printf("fload : %d fstore : %d fops : %d\n", fload, fstore, fops );
	printf("================================================\n");

	return 0;
}

static struct opt_pass mihps_pass = 
{
	.type = GIMPLE_PASS,
	.name = "MIHPS_Profiler", 
	.gate = mihps_profiler_gate,
	.execute = mihps_profiler_exec
};

void plugin_release(void *gcc_data, void *user_data)
{

}

int plugin_init (struct plugin_name_args *plugin_ctx,
		struct plugin_gcc_version *version)
{

	printf("Loading Plugin MIHPS...\n");

	/* Check GCC version */
	if( strncmp( version->basever, "4.7", strlen("4.7") ) ) 
	{
		if( strncmp( version->basever, "4.6", strlen( "4.6" ) ) )
		{
			printf("Error bad GCC version (%s) instead of 4.{6,7}.*\n",
				version->basever);
			return -1;
		}
	}


	/* Fill in new pass informations */
	struct register_pass_info new_pass;

	new_pass.pass = &mihps_pass;
	new_pass.reference_pass_name = "*record_bounds";
	new_pass.ref_pass_instance_number = 1;
	new_pass.pos_op = PASS_POS_INSERT_AFTER;

	/* Register the pass */
	register_callback(plugin_ctx->base_name, PLUGIN_PASS_MANAGER_SETUP, NULL,  &new_pass );

	/* Register plugin infos */
	register_callback(plugin_ctx->base_name, PLUGIN_INFO, NULL, &mihps_plugin_infos );
	register_callback(plugin_ctx->base_name, PLUGIN_FINISH, plugin_release, NULL );

	return 0;
}

