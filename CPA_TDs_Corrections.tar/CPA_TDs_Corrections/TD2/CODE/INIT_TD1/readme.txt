
Deux programmes simples a utiliser pour valider l'installation des packages a utiliser pour les exercices suivants du TD1

== Compiler les binaires
make


== Tester les binaires 
make run


== Sortie attendue

offline@satie:~/Bureau/ENSEIGNEMENT/MHIPS/COMPILATION_2010/TD1/TEST$ make run
lex my_first_lex_file.lex
gcc lex.yy.c -lfl -o lex_test.exe
lex my_second_lex_file.lex
yacc -d my_first_yacc_file.yy
gcc y.tab.c lex.yy.c -lfl -o yacc_test.exe
echo "Testing my toy LEX examlple"
Testing my toy LEX examlple
cat example.txt | ./lex_test.exe
Hello word detected: hello 
Bye word detected : bye 

Hello word detected: hello 

Bye word detected : bye 

Bye word detected : bye 

Bye word detected : bye 

Bye word detected : bye 

Mon premier parseur lex ! 
echo "Testing my toy YACC examlple"
Testing my toy YACC examlple
cat example.txt | ./yacc_test.exe
Mon premier parseur YACC 
Hello word detected
Bye word detected 
yacc: a sentence successfuly parsed 

Hello word detected

Bye word detected 
yacc: a sentence successfuly parsed 

Bye word detected 
Ouch an error occurs in the parsing: syntax error

