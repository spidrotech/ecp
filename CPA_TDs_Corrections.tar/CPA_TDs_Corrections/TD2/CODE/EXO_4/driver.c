
#include <stdio.h>
#include <stdlib.h>

/* 
 * rdstc (Read Time Stamp Counter) est la fonction standard pour acceder au register d'horloge du processeur sur x86.
 * Ce compteur est incrementé de 1 a chaque cycle d'horloge et peut donc servir de 
 * chronometre a grain tres fin pour faire de l'evaluation de performance
 */

unsigned long long int rdtsc(void)
{
	unsigned a, d;

	__asm__ volatile("rdtsc" : "=a" (a), "=d" (d));

	return ((unsigned long long)a) | (((unsigned long long)d) << 32);;
}

#define REPETITION_STABILITE 5000

/*
 * Par defaut les noyaux de calcul ont tous le meme prototype: au plus 3 flots de donnees en entree,
 * et deux scalaire : un double qui peut etre utilisé pour effectuer des operations arithmetiques 
 * sur les flots manipulees et un scalaire entier qui determine le nombre de donnees des flots.
 *
 * On fera toujours attention a manipuler des flots de taille suffisamment petite pour tenir dans
 * le cache L1 ou L2
 */

extern void noyau_a_tester(double *data_flow1, double *data_flow2, double *data_flow3, double scalar, int length);


int main(int argc, char **argv)
{
	double t_start, t_stop;
	int longueur;
	double *flot_1;
	double *flot_2;
	double *flot_3;

	if(argc!=1)
	{
		printf ("Utilisation: driver <longueur_des_flots> \n");
		longueur=atoi(argv[1]);
	}
	else
	{
		printf ("Longeur non définié par l'utilisateur. Selectiond de la valeur par defaut... \n");
		longueur=100;
	}


	printf ("Longueur des flots de donnees manipulés: %d \n", longueur);

	/* Allocation memoire des tableaux */
	flot_1=(double*) malloc(longueur * sizeof(double));
	flot_2=(double*) malloc(longueur * sizeof(double));
	flot_3=(double*) malloc(longueur * sizeof(double));

	printf ("Driver pour l'evaluation de performance \n");

	/* Demarrage de la boucle de mesure */
	t_start=rdtsc();
	/*
	 * On insere une boucle de repetition pour avoir un peu de stabilité experimentale
	 */

	for(int i=0 ; i < REPETITION_STABILITE ; i++)
	{
		noyau_a_tester(flot_1, flot_2, flot_3, 1.0, longueur);
	}

	t_stop=rdtsc() - t_start;
	/* Fin de la boucle de mesure */

	printf ("Temps d'execution total %.0f cycle\n",  t_stop );
	printf ("Temps d'execution total par noyau moyenne sur le facteur de stabilite %.1f cycle\n",  t_stop / REPETITION_STABILITE );
	printf ("Performance par element de tableau manipulé: %.2f cycle\n",  t_stop / (double)(REPETITION_STABILITE * longueur));


	printf ("-- Fin de la mesure --\n");

}
