On fournit l'environnement d'execution permettant de tester et d'evaluer les performances du code assembleur produit.

