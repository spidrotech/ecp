
void noyau_a_tester(double * stream1, double * stream2, double * stream3, double my_scalar, int length)
{
	for(int i=0 ; i < length ; i++)
	{
		stream1[i] = stream2[i] * my_scalar *  stream3[i];
	}
}
