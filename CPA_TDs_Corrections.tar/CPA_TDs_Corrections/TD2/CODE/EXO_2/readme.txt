Deuxieme exercice, toujours un lexer independant de YACC mais on prepare le terrain avec la definition des tokens
necessaire a l'ecriture de petits noyaux de code.

points clefs:

- le parseur a une regle pour detecte registre + nomber et nombre. L'ordre d'apparation de ces deux regles
n'importe pas dans la faculté de Lex à identifier les tokens. En effet c'est la regle du plus grand token qui defini
la precedence des occurences.

- la valeur des tokens utilisé en interne par lex apparait dans l'affichage de leur detection


