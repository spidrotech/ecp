Cet exo a pour but de montrer la structure generale d'un fichier LEX ou le LEXER est utilisé de facon independante a YACC.

Points clefs:

- Definition d'un token (le caractere de fin de fichier)
- Utilisation de variables locales
- le return du parseur (fin de fichier) renvoie la main au main

