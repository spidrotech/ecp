Troisieme exercice, couplage du lexer avec YACC.

L'idee est maintenant de construire un programme verifiant si le code fournit en entree est conforme a la grammaire d'un
noyau assembleur puis de le traduire en vraie assembleur x86.

points clefs:

- Le couplage avec Yacc implique un changement de gestion du main.

- Le couplage avec Yacc fait apparaitre des erreurs dans la definition initiale du langage. Comme la detection des 
registres. La gestion des operations arithmetique doit etre assurées.

- Les token sont maintenus definis dans le fichier Yacc et le ficher Lex peut les utiliser sans avoir 
a les redefinir.

- l'utilisation d'une union pour le type par defaut de variable passerelle entre lex et yacc yyval permet de
passer des informations textuelle a affichier au parser depuis le lexer.

- La gestion d'erreur de parsing se fait via la fonction yyerror()

