
Dans ce dernier exercice on rajoute le support pour des pragma:

- deux types de pragma sont supportés: 
	- unroll:
		- syntaxe: #pragma unroll (n), n etant un entier compris entre 1 et 16
		La boucle est deroulée autant de fois que demandé dans le pragma. Les instructions sont identiques a la boucle d'origine
identiques
	- vectorize
		- syntaxe: #pragma vectorize
		La boucle est déroulée deux fois, mais les instructions de type movaps sont transformées en instruction SSE vectoriel
		de type movpd.


Dans les deux cas, la mesure de performance fournie avec le driver devra permettre des experimentations et des reflexions sur la
notion de bon ou mauvais code.
